﻿#pragma once

#include <cassert>
#define _USE_MATH_DEFINES
#include <cmath>

#include <iostream>
#include <fstream>
#include <iomanip>
#include <vector>

#include <kiam/math/kiam_math_all.h>
using namespace _KIAM_MATH;

typedef int64_t index_type;

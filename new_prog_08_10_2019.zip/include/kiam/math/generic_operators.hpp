#pragma once

#include "math_mpl.hpp"

_KIAM_MATH_BEGIN

template<typename A1, typename A2, typename R>
struct generic_multiplies : std::binary_function<A1, A2, R>
{
	typedef generic_multiplies type;
	typedef std::binary_function<A1, A2, R> super;

	typedef typename super::first_argument_type first_argument_type;
	typedef typename super::second_argument_type second_argument_type;
	typedef typename super::result_type result_type;

	__DEVICE __HOST
	result_type operator()(const first_argument_type &left, const second_argument_type &right) const {
		return left * right;
	};
};

template<typename A1, typename A2, typename R>
struct generic_divides : std::binary_function<A1, A2, R>
{
	typedef generic_divides type;
	typedef std::binary_function<A1, A2, R> super;

	typedef typename super::first_argument_type first_argument_type;
	typedef typename super::second_argument_type second_argument_type;
	typedef typename super::result_type result_type;

	__DEVICE __HOST
	result_type operator()(const first_argument_type &left, const second_argument_type &right) const {
		return left / right;
	};
};

template<typename A1, typename A2, typename R>
struct generic_scalar_product : std::binary_function<A1, A2, R>
{
	typedef generic_scalar_product type;
	typedef std::binary_function<A1, A2, R> super;

	typedef typename super::first_argument_type first_argument_type;
	typedef typename super::second_argument_type second_argument_type;
	typedef typename super::result_type result_type;

	__DEVICE __HOST
	result_type operator()(const first_argument_type &left, const second_argument_type &right) const {
		return left  &right;
	};
};

template<typename A1, typename A2, typename R>
struct generic_component_product : std::binary_function<A1, A2, R>
{
	typedef generic_component_product type;
	typedef std::binary_function<A1, A2, R> super;

	typedef typename super::first_argument_type first_argument_type;
	typedef typename super::second_argument_type second_argument_type;
	typedef typename super::result_type result_type;

	__DEVICE __HOST
	result_type operator()(const first_argument_type &left, const second_argument_type &right) const {
		return left ^ right;
	};
};

struct math_plus_value
{
	template<typename T>
	struct apply {
		typedef plus<T> type;
	};
};

struct math_minus_value
{
	template<typename T>
	struct apply {
		typedef minus<T> type;
	};
};

struct math_multiplies_value
{
	template<typename T>
	struct apply {
		typedef multiplies<T> type;
	};
};

struct math_divides_value
{
	template<typename T>
	struct apply {
		typedef divides<T> type;
	};
};

_KIAM_MATH_END

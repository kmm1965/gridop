#pragma once

#include "generic_operators.hpp"

_KIAM_MATH_BEGIN

template<typename T>
struct get_scalar_type
{
	typedef T type;
};

template<typename T>
using get_scalar_type_t = typename get_scalar_type<T>::type;

template<typename T1, typename T2>
struct supports_multiplies : std::false_type{};

template<>
struct supports_multiplies<float, float> : std::true_type{};

template<>
struct supports_multiplies<double, double> : std::true_type{};

template<>
struct supports_multiplies<long double, long double> : std::true_type{};

#ifdef __CUDACC__

template<>
struct supports_multiplies<float2, float2> : std::true_type{};

template<>
struct supports_multiplies<float2, float> : std::true_type{};

template<>
struct supports_multiplies<float, float2> : std::true_type{};

template<>
struct supports_multiplies<double2, double2> : std::true_type{};

template<>
struct supports_multiplies<double2, double> : std::true_type{};

template<>
struct supports_multiplies<double, double2> : std::true_type{};

#else	// __CUDACC__

template<typename T>
struct supports_multiplies<std::complex<T>, std::complex<T> > : std::true_type{};

template<typename T>
struct supports_multiplies<std::complex<T>, T> : std::true_type{};

template<typename T>
struct supports_multiplies<T, std::complex<T> > : std::true_type{};

#endif	// __CUDACC__

template<typename T1, typename T2>
struct multiplies_result_type;

template<typename T1, typename T2>
using multiplies_result_type_t = typename multiplies_result_type<T1, T2>::type;

template<>
struct multiplies_result_type<float, float>
{
	typedef float type;
};

template<>
struct multiplies_result_type<double, double>
{
	typedef double type;
};

template<>
struct multiplies_result_type<long double, long double>
{
	typedef long double type;
};

#ifdef __CUDACC__

template<>
struct multiplies_result_type<float2, float2>
{
	typedef float2 type;
};

template<>
struct multiplies_result_type<float2, float>
{
	typedef float2 type;
};

template<>
struct multiplies_result_type<float, float2>
{
	typedef float2 type;
};

template<>
struct multiplies_result_type<double2, double2>
{
	typedef double2 type;
};

template<>
struct multiplies_result_type<double2, double>
{
	typedef double2 type;
};

template<>
struct multiplies_result_type<double, double2>
{
	typedef double2 type;
};

#else	// __CUDACC__

template<typename T>
struct multiplies_result_type<std::complex<T>, std::complex<T> >
{
	typedef std::complex<T> type;
};

template<typename T>
struct multiplies_result_type<std::complex<T>, T>
{
	typedef std::complex<T> type;
};

template<typename T>
struct multiplies_result_type<T, std::complex<T> >
{
	typedef std::complex<T> type;
};

#endif	// __CUDACC__

template<typename T1, typename T2>
struct get_generic_multiplies
{
	typedef generic_multiplies<T1, T2, multiplies_result_type_t<T1, T2> > type;
};

template<typename T1, typename T2>
using get_generic_multiplies_t = typename get_generic_multiplies<T1, T2>::type;

template<typename T1, typename T2>
struct supports_divides : std::false_type{};

template<>
struct supports_divides<float, float> : std::true_type{};

template<>
struct supports_divides<double, double> : std::true_type{};

template<>
struct supports_divides<long double, long double> : std::true_type{};

#ifdef __CUDACC__

template<>
struct supports_divides<float2, float2> : std::true_type{};

template<>
struct supports_divides<float2, float> : std::true_type{};

template<>
struct supports_divides<float, float2> : std::true_type{};

template<>
struct supports_divides<double2, double2> : std::true_type{};

template<>
struct supports_divides<double2, double> : std::true_type{};

template<>
struct supports_divides<double, double2> : std::true_type{};

#else	// __CUDACC__

template<typename T>
struct supports_divides<std::complex<T>, std::complex<T> > : std::true_type{};

template<typename T>
struct supports_divides<std::complex<T>, T> : std::true_type{};

template<typename T>
struct supports_divides<T, std::complex<T> > : std::true_type{};

#endif	// __CUDACC__

template<typename T1, typename T2>
struct divides_result_type;

template<typename T1, typename T2>
using divides_result_type_t = typename divides_result_type<T1, T2>::type;

template<>
struct divides_result_type<float, float>
{
	typedef float type;
};

template<>
struct divides_result_type<double, double>
{
	typedef double type;
};

template<>
struct divides_result_type<long double, long double>
{
	typedef long double type;
};

#ifdef __CUDACC__

template<>
struct divides_result_type<float2, float2>
{
	typedef float2 type;
};

template<>
struct divides_result_type<float2, float>
{
	typedef float2 type;
};
template<>
struct divides_result_type<float, float2>
{
	typedef float2 type;
};

template<>
struct divides_result_type<double2, double2>
{
	typedef double2 xtype;
};

template<>
struct divides_result_type<double2, double>
{
	typedef double2 type;
};
template<>
struct divides_result_type<double, double2>
{
	typedef double2 type;
};

#else	// __CUDACC__

template<typename T>
struct divides_result_type<std::complex<T>, std::complex<T> >
{
	typedef std::complex<T> type;
};

template<typename T>
struct divides_result_type<std::complex<T>, T>
{
	typedef std::complex<T> type;
};

template<typename T>
struct divides_result_type<T, std::complex<T> >
{
	typedef std::complex<T> type;
};

#endif	// __CUDACC__

template<typename T1, typename T2>
struct get_generic_divides
{
	typedef generic_divides<T1, T2, divides_result_type_t<T1, T2> > type;
};

template<typename T1, typename T2>
using get_generic_divides_t = typename get_generic_divides<T1, T2>::type;

template<typename T1, typename T2>
struct supports_scalar_product : std::false_type{};

template<typename T1, typename T2>
struct scalar_product_result_type;

template<typename T1, typename T2>
struct get_generic_scalar_product
{
	typedef generic_scalar_product<T1, T2, typename scalar_product_result_type<T1, T2>::type> type;
};

template<typename T1, typename T2>
struct supports_component_product : std::false_type{};

template<typename T1, typename T2>
struct component_product_result_type;

template<typename T1, typename T2>
struct get_generic_component_product
{
	typedef generic_component_product<T1, T2, typename component_product_result_type<T1, T2>::type> type;
};

template<typename T>
struct has_data_type : std::false_type{};

template<typename T>
struct is_quantity_value : std::false_type{};

template<unsigned size> struct int_type;
template<unsigned size> struct uint_type;

template<> struct int_type<1>{
	typedef int8_t type;
};

template<> struct uint_type<1>{
	typedef uint8_t type;
};

template<> struct int_type<2>{
	typedef int16_t type;
};

template<> struct uint_type<2>{
	typedef uint16_t type;
};

template<> struct int_type<4>{
	typedef int32_t type;
};

template<> struct uint_type<4>{
	typedef uint32_t type;
};

template<> struct int_type<8>{
	typedef int64_t type;
};

template<> struct uint_type<8>{
	typedef uint64_t type;
};

typedef int_type<sizeof(size_t)>::type isize_t;

_KIAM_MATH_END

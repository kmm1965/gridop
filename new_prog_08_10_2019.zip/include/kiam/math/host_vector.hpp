#pragma once

#include "math_vector.hpp"

_KIAM_MATH_BEGIN

template<typename T>
struct HOST_VECTOR : public HOST_VECTOR_BASE_CLASS<T>
{
	typedef T value_type;
	typedef HOST_VECTOR type;
	typedef HOST_VECTOR_BASE_CLASS<value_type> super;
	typedef value_type *pointer;
	typedef const value_type *const_pointer;

	HOST_VECTOR(){}
	HOST_VECTOR(size_t size) : super(size){}
	HOST_VECTOR(size_t size, const value_type &initValue) : super(size, initValue){}
#ifndef DONT_USE_CXX_11
	HOST_VECTOR(const HOST_VECTOR&) = delete;
	void operator=(const HOST_VECTOR &other) = delete;
	HOST_VECTOR(HOST_VECTOR &&other) : super(std::forward<super>(other)){}
#endif
	explicit HOST_VECTOR(const MATH_VECTOR<value_type> &other) : super(other){}
#ifdef _INITIALIZER_LIST_
	HOST_VECTOR(std::initializer_list<value_type> ilist) : super(ilist){}
#endif

	vector_proxy<T> get_proxy() const {
		return vector_proxy<T>(super::size(), data_pointer());
	}

	//void operator=(const HOST_VECTOR &other){ super::operator=(other); }
	void operator=(const MATH_VECTOR<value_type> &other){ super::operator=(other); }

	pointer data_pointer(){
#ifdef __CUDACC__
		return thrust::raw_pointer_cast(&super::front());
#else
		return &super::front();
#endif
	}

	const_pointer data_pointer() const {
#ifdef __CUDACC__
		return thrust::raw_pointer_cast(&super::front());
#else
		return &super::front();
#endif
	}
};

_KIAM_MATH_END

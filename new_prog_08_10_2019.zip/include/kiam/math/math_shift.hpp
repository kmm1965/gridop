#pragma once

#include "math_operator.hpp"

_KIAM_MATH_BEGIN

struct math_shift : math_operator<math_shift>
{
	typedef math_shift type;
	typedef math_operator<type> super;

	math_shift(int s) : s(s){}

	template<class EOP, class MC>
	__DEVICE
	typename EOP::value_type
	operator()(size_t i, const EOP &eobj_proxy, const context<typename EOP::tag_type, MC> &context) const {
		return eobj_proxy(i + s, context);
	}

	template<class EOP>
	__DEVICE
	typename EOP::value_type
	operator()(size_t i, const EOP &eobj_proxy) const {
		return eobj_proxy[i + s];
	}

	REIMPLEMENT_MATH_EVAL_OPERATOR()

private:
	int s;
};

template<class EO>
operator_evaluator<math_shift, EO> operator>>(
	const evaluable_object<typename EO::tag_type, EO, typename EO::proxy_type> &eobj,
	int s
){
	return math_shift(s)(eobj);
}

template<class EO>
operator_evaluator<math_shift, EO> operator<<(
	const evaluable_object<typename EO::tag_type, EO, typename EO::proxy_type> &eobj,
	int s
){
	return math_shift(-s)(eobj);
}

_KIAM_MATH_END

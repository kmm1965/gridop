#pragma once

#include "kiam_math.h"

_KIAM_MATH_BEGIN

template<class T>
struct vector_value
{
	typedef vector_value type;
	typedef T data_type;
	typedef data_type &reference;
	typedef const data_type &const_reference;

	__DEVICE __HOST
	vector_value() : m_value_x(data_type()), m_value_y(data_type()), m_value_z(data_type()){}

	__DEVICE __HOST
	vector_value(const data_type &x, const data_type &y, const data_type &z) : m_value_x(x), m_value_y(y), m_value_z(z){}

	__DEVICE __HOST
	vector_value(const vector_value &rhs) : m_value_x(rhs.value_x()), m_value_y(rhs.value_y()), m_value_z(rhs.value_z()){}

	__DEVICE __HOST
	vector_value& operator=(const vector_value &rhs)
	{
		m_value_x = rhs.value_x();
		m_value_y = rhs.value_y();
		m_value_z = rhs.value_z();
		return *this;
	}

	__DEVICE __HOST
	void set(const data_type &x, const data_type &y, const data_type &z)
	{
		m_value_x = x;
		m_value_y = y;
		m_value_z = z;
	}

	__DEVICE __HOST
	const_reference value_x() const { return m_value_x; }

	__DEVICE __HOST
	const_reference value_y() const { return m_value_y; }

	__DEVICE __HOST
	const_reference value_z() const { return m_value_z; }

	__DEVICE __HOST
	reference value_x(){ return m_value_x; }

	__DEVICE __HOST
	reference value_y(){ return m_value_y; }

	__DEVICE __HOST
	reference value_z(){ return m_value_z; }

	__DEVICE __HOST
	void value_x(const data_type &value){ m_value_x = value; }

	__DEVICE __HOST
	void value_y(const data_type &value){ m_value_y = value; }

	__DEVICE __HOST
	void value_z(const data_type &value){ m_value_z = value; }

	__DEVICE __HOST
	const_reference operator[](unsigned n) const
	{
		assert(n < 3);
		return n == 0 ? m_value_x : n == 1 ? m_value_y : m_value_z;
	}

	__DEVICE __HOST
	reference operator[](unsigned n)
	{
		assert(n < 3);
		return n == 0 ? m_value_x : n == 1 ? m_value_y : m_value_z;
	}

	__DEVICE __HOST
	data_type value_xy() const { return data_type(m_value_x * m_value_y); }

	__DEVICE __HOST
	data_type value_xz() const { return data_type(m_value_x * m_value_z); }

	__DEVICE __HOST
	data_type value_yz() const { return data_type(m_value_y * m_value_z); }

	__DEVICE __HOST
	vector_value& operator+=(const vector_value &rhs)
	{
		m_value_x += rhs.value_x();
		m_value_y += rhs.value_y();
		m_value_z += rhs.value_z();
		return *this;
	}

	__DEVICE __HOST
	vector_value& operator-=(const vector_value &rhs)
	{
		m_value_x -= rhs.value_x();
		m_value_y -= rhs.value_y();
		m_value_z -= rhs.value_z();
		return *this;
	}

	__DEVICE __HOST
	vector_value& operator*=(const data_type &rhs)
	{
		m_value_x *= rhs;
		m_value_y *= rhs;
		m_value_z *= rhs;
		return *this;
	}

	__DEVICE __HOST
	vector_value& operator/=(const data_type &rhs)
	{
		m_value_x /= rhs;
		m_value_y /= rhs;
		m_value_z /= rhs;
		return *this;
	}

	__DEVICE __HOST
	data_type length() const {
		return func::sqrt(sqr());
	}

	__DEVICE __HOST
	data_type sqr() const {
		return m_value_x * m_value_x + m_value_y * m_value_y + m_value_z * m_value_z;
	}

	__DEVICE __HOST
	vector_value operator-() const {
		return vector_value(-m_value_x, -m_value_y, -m_value_z);
	}

	__DEVICE __HOST
	bool operator==(const vector_value &rhs) const {
		return m_value_x == rhs.value_x() && m_value_y == rhs.value_y() && m_value_z == rhs.value_z();
	}

	__DEVICE __HOST
	bool operator!=(const vector_value &rhs) const {
		return m_value_x != rhs.value_x() || m_value_y != rhs.value_y() || m_value_z != rhs.value_z();
	}

	__DEVICE __HOST
	vector_value norm(){
		return *this *= 1 / length();
	}

private:
	data_type m_value_x, m_value_y, m_value_z;
};

template<class T>
__DEVICE __HOST
vector_value<T> operator+(const vector_value<T> &x, const vector_value<T> &y){
	return vector_value<T>(x.value_x() + y.value_x(), x.value_y() + y.value_y(), x.value_z() + y.value_z());
}

template<class T>
__DEVICE __HOST
vector_value<T> operator-(const vector_value<T> &x, const vector_value<T> &y){
	return vector_value<T>(x.value_x() - y.value_x(), x.value_y() - y.value_y(), x.value_z() - y.value_z());
}

template<class T>
__DEVICE __HOST
vector_value<T> operator*(const vector_value<T> &x, T y){
	return vector_value<T>(x.value_x() * y, x.value_y() * y, x.value_z() * y);
}

template<class T>
__DEVICE __HOST
vector_value<T> operator*(T x, const vector_value<T> &y){
	return vector_value<T>(x * y.value_x(), x * y.value_y(), x * y.value_z());
}

template<class T>
__DEVICE __HOST
vector_value<T> operator/(const vector_value<T> &x, T y){
	return vector_value<T>(x.value_x() / y, x.value_y() / y, x.value_z() / y);
}

// �������������� �������
template<class T>
__DEVICE __HOST
vector_value<T> operator/(const vector_value<T> &x, const vector_value<T> &y){
	return vector_value<T>(x.value_x() / y.value_x(), x.value_y() / y.value_y(), x.value_z() / y.value_z());
}

// ��������� ������������
template<class T>
__DEVICE __HOST
vector_value<T> operator*(const vector_value<T> &x, const vector_value<T> &y)
{
	return vector_value<T>(
		x.value_y() * y.value_z() - x.value_z() * y.value_y(),
		x.value_z() * y.value_x() - x.value_x() * y.value_z(),
		x.value_x() * y.value_y() - x.value_y() * y.value_x());
}

// ��������� ������������
template<class T>
__DEVICE __HOST
T operator&(const vector_value<T> &x, const vector_value<T> &y){
	return x.value_x() * y.value_x() + x.value_y() * y.value_y() + x.value_z() * y.value_z();
}

// �������������� ������������
template<class T>
__DEVICE __HOST
vector_value<T> operator^(const vector_value<T> &x, const vector_value<T> &y){
	return vector_value<T>(
		x.value_x() * y.value_x(),
		x.value_y() * y.value_y(),
		x.value_z() * y.value_z());
}

namespace func {

template<class T>
__DEVICE __HOST
T sqr(const vector_value<T> &x){
	return x  &x;
}

template<class T>
__DEVICE __HOST
T abs(const vector_value<T> &x){
	return x.length();
}

template<class T>
__DEVICE __HOST
vector_value<T> vabs(const vector_value<T> &x){
	return vector_value<T>(func::abs(x.value_x()), func::abs(x.value_y()), func::abs(x.value_z()));
}

template<class T>
__DEVICE __HOST
T sum_abs(const vector_value<T> &x){
	return func::abs(x.value_x()) + func::abs(x.value_y()) + func::abs(x.value_z());
}

}	// namespace func

template <class T> struct is_vector_value : std::false_type {};
template <class T> struct is_vector_value<const T> : is_vector_value<T>{};
template <class T> struct is_vector_value<volatile const T> : is_vector_value<T>{};
template <class T> struct is_vector_value<volatile T> : is_vector_value<T>{};
template <class T> struct is_vector_value<vector_value<T> > : std::true_type{};

template<typename T>
struct supports_multiplies<vector_value<T>, vector_value<T> > : std::true_type{};

template<typename T>
struct multiplies_result_type<vector_value<T>, vector_value<T> >
{
	typedef vector_value<T> type;
};

template<typename T>
struct supports_multiplies<vector_value<T>, T> : std::true_type{};

template<typename T>
struct multiplies_result_type<vector_value<T>, T>
{
	typedef vector_value<T> type;
};

template<typename T>
struct supports_multiplies<T, vector_value<T> > : std::true_type{};

template<typename T>
struct multiplies_result_type<T, vector_value<T> >
{
	typedef vector_value<T> type;
};

template<typename T>
struct supports_divides<vector_value<T>, T> : std::true_type{};

template<typename T>
struct divides_result_type<vector_value<T>, T>
{
	typedef vector_value<T> type;
};

template<typename T>
struct supports_scalar_product<vector_value<T>, vector_value<T> > : std::true_type{};

template<typename T>
struct scalar_product_result_type<vector_value<T>, vector_value<T> >
{
	typedef T type;
};

template<typename T>
struct supports_component_product<vector_value<T>, vector_value<T> > : std::true_type{};

template<typename T>
struct component_product_result_type<vector_value<T>, vector_value<T> >
{
	typedef vector_value<T> type;
};

template<typename T>
struct has_data_type<vector_value<T> > : std::true_type{};

template<typename T>
struct get_scalar_type<vector_value<T> >
{
	typedef T type;
};

_KIAM_MATH_END

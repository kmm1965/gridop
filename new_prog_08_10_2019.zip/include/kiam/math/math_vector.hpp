#pragma once

#include "math_def.h"

#if defined(__CUDACC__)
#include <thrust/device_vector.h>
#elif defined(__OPENCL__)
#include <boost/compute/container/vector.hpp>
#else
#include <vector>
#endif

_KIAM_MATH_BEGIN

#if defined(__CUDACC__)
#define MATH_VECTOR math_vector_cuda
#define HOST_VECTOR host_vector_cuda
#define MATH_VECTOR_BASE_CLASS thrust::device_vector
#define HOST_VECTOR_BASE_CLASS thrust::host_vector
#define HOST_VECTOR_T _KIAM_MATH::HOST_VECTOR
#elif defined(__OPENCL__)
#define MATH_VECTOR math_vector_opencl
#define HOST_VECTOR host_vector_opencl
#define MATH_VECTOR_BASE_CLASS ::boost::compute::vector
#define HOST_VECTOR_BASE_CLASS std::vector
#define HOST_VECTOR_T _KIAM_MATH::HOST_VECTOR
#else
#define MATH_VECTOR math_vector_cpu
#define HOST_VECTOR host_vector_cpu
#define MATH_VECTOR_BASE_CLASS std::vector
#define HOST_VECTOR_BASE_CLASS std::vector
#define HOST_VECTOR_T _KIAM_MATH::MATH_VECTOR
#endif

template<typename T>
struct HOST_VECTOR;

template<typename T>
struct vector_proxy;

template<typename T>
struct MATH_VECTOR : public MATH_VECTOR_BASE_CLASS<T>
{
	typedef MATH_VECTOR type;
	typedef T value_type;
	typedef MATH_VECTOR_BASE_CLASS<value_type> super;
	typedef value_type *pointer;
	typedef const value_type *const_pointer;
	typedef vector_proxy<value_type> vector_proxy_type;

	MATH_VECTOR() : super(){}
	MATH_VECTOR(size_t size) : super(size){}
	MATH_VECTOR(size_t size, const value_type &initValue) : super(size, initValue){}
#ifndef DONT_USE_CXX_11
	MATH_VECTOR(const MATH_VECTOR &other) : super(other){};
	MATH_VECTOR(MATH_VECTOR &&other) : super(std::forward<super>(other)){}
#endif
	MATH_VECTOR(const HOST_VECTOR<value_type>& hv) : super(hv){}
#if !defined (__CUDACC__) && defined(_INITIALIZER_LIST_)
	MATH_VECTOR(std::initializer_list<value_type> ilist) : super(ilist){}
#endif

	void operator=(const MATH_VECTOR &other){ super::operator=(other); }
	void operator=(MATH_VECTOR &&other){ super::operator=(std::forward<super>(other)); }

	void operator=(const HOST_VECTOR<value_type> &hv)
	{
#ifdef __CUDACC__
		size_t size = hv.size();
		if(super::size() != size)
			super::resize(size);
		if (size > 0){
			cudaError_t error = cudaMemcpy(data_pointer(), hv.data_pointer(), size * sizeof(value_type), cudaMemcpyHostToDevice);
			if (error)
				throw thrust::system_error(error, thrust::cuda_category());
		}
#else
		super::operator=(hv);
#endif
	}

	pointer data_pointer(){
#if defined(__CUDACC__)
		return thrust::raw_pointer_cast(&super::front());
#elif defined(__OPENCL__)
        return (pointer)(&super::front()).get_buffer().get();
#else
		return &super::front();
#endif
	}

	const_pointer data_pointer() const {
#if defined(__CUDACC__)
        return thrust::raw_pointer_cast(&super::front());
#elif defined(__OPENCL__)
        return (const_pointer)(&super::front()).get_buffer().get();
#else
		return &super::front();
#endif
	}

	vector_proxy<T> get_proxy() const {
		return vector_proxy<T>(super::size(), data_pointer());
	}
};

_KIAM_MATH_END

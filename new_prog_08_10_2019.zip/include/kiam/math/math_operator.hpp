#pragma once

#include "context.hpp"
#include "evaluable_object.hpp"
#include <boost/preprocessor/repeat_from_to.hpp>
#include <boost/preprocessor/enum.hpp>
#include <boost/preprocessor/enum_params.hpp>

#ifndef MAX_MATH_OPERATOR_PARAMS
#define MAX_MATH_OPERATOR_PARAMS 2
#endif

_KIAM_MATH_BEGIN

template<class MO, class _Proxy = MO>
struct math_operator;

template<class MO, class EO>
struct operator_evaluator : evaluable_object<typename MO::template get_tag_type<typename EO::tag_type>::type, operator_evaluator<MO, EO> >
{
	typedef operator_evaluator type;
	typedef typename MO::template get_tag_type<typename EO::tag_type>::type tag_type;
	typedef evaluable_object<tag_type, type> super;
	typedef typename MO::template get_value_type<typename EO::value_type>::type value_type;
	typedef math_operator<MO, typename MO::proxy_type> op_type;
	typedef evaluable_object<typename EO::tag_type, EO, typename EO::proxy_type> eobj_type;

	operator_evaluator(const op_type &op, const eobj_type &eobj) : op_proxy(op.get_proxy()), eobj_proxy(eobj.get_proxy()){}

	__DEVICE
	value_type operator[](size_t i) const {
		return op_proxy(i, eobj_proxy);
	}

	__DEVICE
	value_type operator()(size_t i) const {
		return op_proxy(i, eobj_proxy);
	}

	template<class MC>
	__DEVICE
	value_type operator()(size_t i, const context<tag_type, MC> &context) const {
		return op_proxy(i, eobj_proxy, context);
	}

private:
	const typename MO::proxy_type op_proxy;
	const typename EO::proxy_type eobj_proxy;
};

#define MATH_OPERATOR_EVALUATOR_EO_VALUE_TYPE(z, n, unused) typename EO##n::value_type
#define MATH_OPERATOR_EVALUATOR_EOBJ_TYPE(z, n, unused) \
	typedef evaluable_object<typename EO##n::tag_type, EO##n, typename EO##n::proxy_type> eobj##n##_type;
#define MATH_OPERATOR_EVALUATOR_EOBJ(z, n, unused) const eobj##n##_type &eobj##n
#define MATH_OPERATOR_EVALUATOR_EOBJ_PROXY_INIT(z, n, unused) eobj##n##_proxy(eobj##n.get_proxy())
#define MATH_OPERATOR_EVALUATOR_EOBJ_PROXY(z, n, unused) eobj##n##_proxy
#define MATH_OPERATOR_EVALUATOR_EOBJ_PROXY_DEF(z, n, unused) const typename EO##n::proxy_type eobj##n##_proxy;

#define MATH_OPERATOR_EVALUATOR(z, n, unused) \
	template<class MO, BOOST_PP_ENUM_PARAMS(n, class EO)> \
	struct operator_evaluator##n : evaluable_object<typename MO::tag_type, operator_evaluator##n<MO, BOOST_PP_ENUM_PARAMS(n, EO)> > \
	{ \
		typedef operator_evaluator##n type; \
		typedef evaluable_object<typename MO::tag_type, type> super; \
		typedef typename MO::template get_value_type##n<BOOST_PP_ENUM(n, MATH_OPERATOR_EVALUATOR_EO_VALUE_TYPE, ~)>::type value_type; \
		typedef math_operator<MO, typename MO::proxy_type> op_type; \
		BOOST_PP_REPEAT(n, MATH_OPERATOR_EVALUATOR_EOBJ_TYPE, ~) \
		operator_evaluator##n(const op_type &op, BOOST_PP_ENUM(n, MATH_OPERATOR_EVALUATOR_EOBJ, ~)) : \
			op_proxy(op.get_proxy()), BOOST_PP_ENUM(n, MATH_OPERATOR_EVALUATOR_EOBJ_PROXY_INIT, ~){} \
		__DEVICE \
		value_type operator[](size_t i) const { \
			return op_proxy(i, BOOST_PP_ENUM(n, MATH_OPERATOR_EVALUATOR_EOBJ_PROXY, ~)); \
		} \
		__DEVICE \
		value_type operator()(size_t i) const { \
			return op_proxy(i, BOOST_PP_ENUM(n, MATH_OPERATOR_EVALUATOR_EOBJ_PROXY, ~)); \
		} \
	private: \
		const typename MO::proxy_type op_proxy; \
		BOOST_PP_REPEAT(n, MATH_OPERATOR_EVALUATOR_EOBJ_PROXY_DEF, ~) \
	};

BOOST_PP_REPEAT_FROM_TO(2, BOOST_PP_INC(MAX_MATH_OPERATOR_PARAMS), MATH_OPERATOR_EVALUATOR, ~)
#undef MATH_OPERATOR_EVALUATOR_EO_VALUE_TYPE
#undef MATH_OPERATOR_EVALUATOR_EOBJ_TYPE
#undef MATH_OPERATOR_EVALUATOR_EOBJ
#undef MATH_OPERATOR_EVALUATOR_EOBJ_PROXY_INIT
#undef MATH_OPERATOR_EVALUATOR_EOBJ_PROXY
#undef MATH_OPERATOR_EVALUATOR_EOBJ_PROXY_DEF
#undef MATH_OPERATOR_EVALUATOR

template<class MO, class _Proxy>
struct math_operator : math_object<MO, _Proxy>
{
	template<typename EO_TAG>
	struct get_tag_type
	{
		typedef EO_TAG type;
	};

	template<typename T>
	struct get_value_type
	{
		typedef T type;
	};

#define MATH_OPERATOR_T(z, n, unused) T
#define MATH_OPERATOR_GET_VALUE_TYPE(z, n, unused) \
	template<BOOST_PP_ENUM_PARAMS(n, typename T)> struct get_value_type##n; \
	template<typename T> struct get_value_type##n<BOOST_PP_ENUM(n, MATH_OPERATOR_T, ~)>{ \
		typedef T type; \
	};
	BOOST_PP_REPEAT_FROM_TO(2, BOOST_PP_INC(MAX_MATH_OPERATOR_PARAMS), MATH_OPERATOR_GET_VALUE_TYPE, ~)
#undef MATH_OPERATOR_T
#undef MATH_OPERATOR_GET_VALUE_TYPE

	template<class EO>
	operator_evaluator<MO, EO> operator()(const evaluable_object<typename EO::tag_type, EO, typename EO::proxy_type> &eobj) const {
		return operator_evaluator<MO, EO>(*this, eobj);
	}

#define MATH_OPERATOR_EOBJ(z, n, unused) \
	const evaluable_object<typename EO##n::tag_type, EO##n, typename EO##n::proxy_type> &eobj##n
#define MATH_OPERATOR_BRACKET(z, n, unused) \
	template<BOOST_PP_ENUM_PARAMS(n, class EO)> \
	operator_evaluator##n<MO, BOOST_PP_ENUM_PARAMS(n, EO)> \
	operator()(BOOST_PP_ENUM(n, MATH_OPERATOR_EOBJ, ~)) const { \
		return operator_evaluator##n<MO, BOOST_PP_ENUM_PARAMS(n, EO)>(*this, BOOST_PP_ENUM_PARAMS(n, eobj)); \
	}
	BOOST_PP_REPEAT_FROM_TO(2, BOOST_PP_INC(MAX_MATH_OPERATOR_PARAMS), MATH_OPERATOR_BRACKET, ~)
#undef MATH_OPERATOR_EOBJ
#undef MATH_OPERATOR_BRACKET
};

_KIAM_MATH_END

#define REIMPLEMENT_OPERATOR_EXEC() \
    template<typename EOP> \
    __DEVICE \
    typename EOP::value_type operator()(size_t i, EOP const& eobj_proxy) const { \
        return super::operator()(i, eobj_proxy); \
    }

#define REIMPLEMENT_MATH_EVAL_OPERATOR() \
	template<class EO> \
	_KIAM_MATH::operator_evaluator<type, EO> operator()(const _KIAM_MATH::evaluable_object<typename EO::tag_type, EO, typename EO::proxy_type> &eobj) const { \
		return _KIAM_MATH::math_operator<type>::operator()(eobj); \
	}

#define REIMPLEMENT_MATH_EVAL_OPERATOR_EOBJ(z, n, unused) \
	const _KIAM_MATH::evaluable_object<typename EO##n::tag_type, EO##n, typename EO##n::proxy_type> &eobj##n

#define REIMPLEMENT_MATH_EVAL_OPERATOR_N(n) \
	template<BOOST_PP_ENUM_PARAMS(n, class EO)> \
	_KIAM_MATH::operator_evaluator##n<type, BOOST_PP_ENUM_PARAMS(n, EO)> \
	operator()(BOOST_PP_ENUM(n, REIMPLEMENT_MATH_EVAL_OPERATOR_EOBJ, ~)) const { \
		return _KIAM_MATH::math_operator<type>::operator()(BOOST_PP_ENUM_PARAMS(n, eobj)); \
	}

#define REIMPLEMENT_MATH_EVAL_OPERATOR2() REIMPLEMENT_MATH_EVAL_OPERATOR_N(2)
#if MAX_MATH_OPERATOR_PARAMS > 2
#define REIMPLEMENT_MATH_EVAL_OPERATOR3() REIMPLEMENT_MATH_EVAL_OPERATOR_N(3)
#if MAX_MATH_OPERATOR_PARAMS > 3
#define REIMPLEMENT_MATH_EVAL_OPERATOR4() REIMPLEMENT_MATH_EVAL_OPERATOR_N(4)
#if MAX_MATH_OPERATOR_PARAMS > 4
#define REIMPLEMENT_MATH_EVAL_OPERATOR5() REIMPLEMENT_MATH_EVAL_OPERATOR_N(5)
#endif
#endif
#endif

//#ifdef DONT_USE_CXX_11
//#define DECLARE_MATH_OPERATOR(name) \
//	template<class MO, class EO> \
//	struct name##_operator_evaluator : _KIAM_MATH::operator_evaluator<MO, EO>{}; \
//	template<class MO, class _Proxy = MO> \
//	struct name##_operator : _KIAM_MATH::math_operator<MO, _Proxy>{}
//#else
//#define DECLARE_MATH_OPERATOR(name) \
//	template<class MO, class EO> \
//	using name##_operator_evaluator = _KIAM_MATH::operator_evaluator<MO, EO>; \
//	template<class MO, class _Proxy = MO> \
//	using name##_operator = _KIAM_MATH::math_operator<MO, _Proxy>
//#endif

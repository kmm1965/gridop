#pragma once

#include "quantity_dim.hpp"

_KIAM_MATH_BEGIN

template<BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class D)>
struct get_array_size
{
	static const unsigned value = MAX_ARRAY_DIM_SIZE;
};

#define GET_ARRAY_SIZE_impl(z, n, unused) \
	template<BOOST_PP_ENUM_PARAMS(n, class D)> \
	struct get_array_size< \
		BOOST_PP_ENUM_PARAMS(n, D), \
		BOOST_PP_ENUM(BOOST_PP_SUB(MAX_ARRAY_DIM_SIZE, n), BOOST_PP_ENUM_print_data, void) \
	>{ static const unsigned value = n; };

BOOST_PP_REPEAT_FROM_TO(1, MAX_ARRAY_DIM_SIZE, GET_ARRAY_SIZE_impl, ~)

#undef GET_ARRAY_SIZE_impl

template<unsigned I, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class D)>
struct get_array_dim;

#define GET_ARRAY_DIM_impl(z, n, unused) \
	template<BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class D)> \
	struct get_array_dim<n, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, D)>{ typedef D##n type; };
BOOST_PP_REPEAT(MAX_ARRAY_DIM_SIZE, GET_ARRAY_DIM_impl, ~)
#undef GET_ARRAY_DIM_impl

template<class T, class D0,
	#define ARRAY_DIM_QUANTITY_TMP_param0(n) class D##n = void
	#define ARRAY_DIM_QUANTITY_TMP_param(z, n, unused) ARRAY_DIM_QUANTITY_TMP_param0(n)
	BOOST_PP_ENUM_SHIFTED(MAX_ARRAY_DIM_SIZE, ARRAY_DIM_QUANTITY_TMP_param, ~)
	#undef ARRAY_DIM_QUANTITY_TMP_param0
	#undef ARRAY_DIM_QUANTITY_TMP_param
>
struct array_dim_quantity
{
	typedef array_dim_quantity type;
	typedef T data_type;
	typedef data_type *pointer;
	typedef const data_type *const_pointer;
	typedef data_type &reference;
	typedef const data_type &const_reference;

	#define ARRAY_DIM_QUANTITY_dim(z, n, unused) typedef D##n dim##n;
	BOOST_PP_REPEAT(MAX_ARRAY_DIM_SIZE, ARRAY_DIM_QUANTITY_dim, ~)
	#undef ARRAY_DIM_QUANTITY_dim

	static const unsigned array_size = get_array_size<BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, dim)>::value;
	MATH_STATIC_ASSERT(array_size > 0);

	template<unsigned I>
	struct quantity_type
	{
		MATH_STATIC_ASSERT(I < array_size);
		typedef quantity<data_type, typename get_array_dim<I, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, dim)>::type> type;
	};

	__DEVICE __HOST
	array_dim_quantity(){
		fill_n(m_values, array_size, data_type());
	}

	__DEVICE __HOST
	array_dim_quantity(const array_dim_quantity &rhs){
		copy(rhs.m_values, rhs.m_values + array_size, m_values);
	}

	__DEVICE __HOST
	pointer values(){ return m_values; }

	__DEVICE __HOST
	const_pointer values() const { return m_values; }

	__DEVICE __HOST
	data_type operator[](unsigned i) const { return m_values[i]; }

	__DEVICE __HOST
	reference operator[](unsigned i){ return m_values[i]; }

	template<unsigned I>
	__DEVICE __HOST
	typename quantity_type<I>::type
	qvalue() const { return typename quantity_type<I>::type(m_values[I]); }

	template<unsigned I>
	__DEVICE __HOST
	void qvalue(typename quantity_type<I>::type value){ m_values[I] = value.value(); }

	__DEVICE __HOST
	array_dim_quantity& operator+=(const array_dim_quantity &rhs)
	{
		transform_n(m_values, rhs.m_values, array_size, m_values, plus<data_type>());
		return *this;
	}

	__DEVICE __HOST
	array_dim_quantity& operator-=(const array_dim_quantity &rhs)
	{
		transform_n(m_values, rhs.m_values, array_size, m_values, minus<data_type>());
		return *this;
	}

	__DEVICE __HOST
	array_dim_quantity& operator*=(data_type rhs)
	{
		transform_n(m_values, array_size, m_values, math_bind2nd(multiplies<data_type>(), rhs));
		return *this;
	}

	__DEVICE __HOST
	array_dim_quantity& operator/=(data_type rhs)
	{
		transform_n(m_values, array_size, m_values, math_bind2nd(divides<data_type>(), rhs));
		return *this;
	}

	__DEVICE __HOST
	array_dim_quantity& operator*=(const quantity<data_type, scalar> &rhs)
	{
		transform_n(m_values, array_size, m_values, math_bind2nd(multiplies<data_type>(), rhs.value()));
		return *this;
	}

	__DEVICE __HOST
	array_dim_quantity& operator/=(const quantity<data_type, scalar> &rhs)
	{
		transform_n(m_values, array_size, m_values, math_bind2nd(divides<data_type>(), rhs.value()));
		return *this;
	}

	__DEVICE __HOST
	array_dim_quantity operator-() const
	{
		array_dim_quantity result;
		transform_n(m_values, array_size, result.m_values, negate<data_type>());
		return result;
	}

	__DEVICE __HOST
	bool operator==(const array_dim_quantity &rhs) const {
		return math_inner_product_n(m_values, rhs.m_values, array_size, true, logical_and<bool>(), equal_to<data_type>());
	}

	__DEVICE __HOST
	bool operator!=(const array_dim_quantity &rhs) const {
		return math_inner_product_n(m_values, rhs.m_values, array_size, false, logical_or<bool>(), not_equal_to<data_type>());
	}

private:
	data_type m_values[array_size];
};

struct void_type
{
	typedef void type;
};

template<class D1, class D2>
struct array_dim_add_dimensions : add_dimensions<D1, D2>{};

template<class D1>
struct array_dim_add_dimensions<D1, void> : void_type {};

template<class D2>
struct array_dim_add_dimensions<void, D2> : void_type {};

template<>
struct array_dim_add_dimensions<void, void> : void_type {};

template<class D1, class D2>
struct array_dim_sub_dimensions : sub_dimensions<D1, D2>{};

template<class D1>
struct array_dim_sub_dimensions<D1, void> : void_type {};

template<class D2>
struct array_dim_sub_dimensions<void, D2> : void_type {};

template<>
struct array_dim_sub_dimensions<void, void> : void_type {};

template<class D1, class D2, bool add_dim>
struct array_dim_calc_dimension : calc_dimension<D1, D2, add_dim>{};

template<class D1, bool add_dim>
struct array_dim_calc_dimension<D1, void, add_dim> : void_type {};

template<class D2, bool add_dim>
struct array_dim_calc_dimension<void, D2, add_dim> : void_type {};

template<bool add_dim>
struct array_dim_calc_dimension<void, void, add_dim> : void_type {};

template<class T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class D)>
__DEVICE __HOST
array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, D)> operator+(
	const array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, D)> &x,
	const array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, D)> &y)
{
	array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, D)> result;
	transform_n(x.values(), y.values(), get_array_size<BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, D)>::value, result.values(), plus<T>());
	return result;
}

template<class T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class D)>
__DEVICE __HOST
array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, D)> operator-(
	const array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, D)> &x,
	const array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, D)> &y)
{
	array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, D)> result;
	transform_n(x.values(), y.values(), get_array_size<BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, D)>::value, result.values(), minus<T>());
	return result;
}

#define RESULT_DIMS_param(z, n, unused) typename array_dim_add_dimensions<DX##n, DY>::type
#define RESULT_DIMS BOOST_PP_ENUM(MAX_ARRAY_DIM_SIZE, RESULT_DIMS_param, ~)
template<class T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class DX), class DY>
__DEVICE __HOST
array_dim_quantity<T, RESULT_DIMS>
operator*(const array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, DX)> &x, const quantity<T, DY> &y)
{
	array_dim_quantity<T, RESULT_DIMS> result;
	transform_n(x.values(), x.array_size, result.values(), math_bind2nd(multiplies<T>(), y.value()));
	return result;
}
#undef RESULT_DIMS_param
#undef RESULT_DIMS

#define RESULT_DIMS_param(z, n, unused) typename array_dim_add_dimensions<DX, DY##n>::type
#define RESULT_DIMS BOOST_PP_ENUM(MAX_ARRAY_DIM_SIZE, RESULT_DIMS_param, ~)
template<class T, class DX, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class DY)>
__DEVICE __HOST
array_dim_quantity<T, RESULT_DIMS>
operator*(const quantity<T, DX> &x, const array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, DY)> &y)
{
	array_dim_quantity<T, RESULT_DIMS> result;
	transform_n(y.values(), y.array_size, result.values(), math_bind1st(multiplies<T>(), x.value()));
	return result;
}
#undef RESULT_DIMS_param
#undef RESULT_DIMS

#define RESULT_DIMS_param(z, n, unused) typename array_dim_sub_dimensions<DX##n, DY>::type
#define RESULT_DIMS BOOST_PP_ENUM(MAX_ARRAY_DIM_SIZE, RESULT_DIMS_param, ~)
template<class T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class DX), class DY>
__DEVICE __HOST
array_dim_quantity<T, RESULT_DIMS>
operator/(
	const array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, DX)> &x,
	const quantity<T, DY> &y
){
	array_dim_quantity<T, RESULT_DIMS> result;
	transform_n(x.values(), x.array_size, result.values(), math_bind2nd(divides<T>(), y.value()));
	return result;
}
#undef RESULT_DIMS_param
#undef RESULT_DIMS

template<class T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class DX)>
__DEVICE __HOST
array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, DX)>
operator*(const array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, DX)> &x, T y)
{
	array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, DX)> result;
	transform_n(x.values(), x.array_size, result.values(), math_bind2nd(multiplies<T>(), y));
	return result;
}

template<class T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class DY)>
__DEVICE __HOST
array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, DY)>
operator*(T x, const array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, DY)> &y)
{
	array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, DY)> result;
	transform_n(y.values(), y.array_size, result.values(), math_bind1st(multiplies<T>(), x));
	return result;
}

template<class T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class DX)>
__DEVICE __HOST
array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, DX)>
operator/(const array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, DX)> &x, T y)
{
	array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, DX)> result;
	transform_n(x.values(), x.array_size, result.values(), math_bind2nd(divides<T>(), y));
	return result;
}

// �������������� ������������
#define RESULT_DIMS_param(z, n, unused) typename array_dim_add_dimensions<DX##n, DY##n>::type
#define RESULT_DIMS BOOST_PP_ENUM(MAX_ARRAY_DIM_SIZE, RESULT_DIMS_param, ~)
template<class T,
	BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class DX),
	BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class DY)
>
__DEVICE __HOST
array_dim_quantity<T, RESULT_DIMS>
operator^(
	const array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, DX)> &x,
	const array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, DY)> &y
){
	MATH_STATIC_ASSERT((get_array_size<BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, DX)>::value == get_array_size<BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, DY)>::value));
	array_dim_quantity<T, RESULT_DIMS> result;
	transform_n(x.values(), y.values(), x.array_size, result.values(), multiplies<T>());
	return result;
}
#undef RESULT_DIMS_param
#undef RESULT_DIMS

template <class T> struct is_array_dim_quantity : std::false_type {};
template <class T> struct is_array_dim_quantity<const T> : is_array_dim_quantity<T>{};
template <class T> struct is_array_dim_quantity<volatile const T> : is_array_dim_quantity<T>{};
template <class T> struct is_array_dim_quantity<volatile T> : is_array_dim_quantity<T>{};

template<class T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class D)>
struct is_array_dim_quantity<array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, D)> > : std::true_type{};

template<typename T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class DX), class DY>
struct supports_multiplies<array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, DX)>, quantity<T, DY> > : std::true_type{};

#define RESULT_DIMS_param(z, n, unused) typename array_dim_add_dimensions<DX##n, DY>::type
#define RESULT_DIMS BOOST_PP_ENUM(MAX_ARRAY_DIM_SIZE, RESULT_DIMS_param, ~)
template<typename T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class DX), class DY>
struct multiplies_result_type<array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, DX)>, quantity<T, DY> >
{
	typedef array_dim_quantity<T, RESULT_DIMS> type;
};
#undef RESULT_DIMS_param
#undef RESULT_DIMS

template<typename T, class DX, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class DY)>
struct supports_multiplies<quantity<T, DX>, array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, DY)> > : std::true_type{};

#define RESULT_DIMS_param(z, n, unused) typename array_dim_add_dimensions<DX, DY##n>::type
#define RESULT_DIMS BOOST_PP_ENUM(MAX_ARRAY_DIM_SIZE, RESULT_DIMS_param, ~)
template<typename T, class DX, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class DY)>
struct multiplies_result_type<quantity<T, DX>, array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, DY)> >
{
	typedef array_dim_quantity<T, RESULT_DIMS> type;
};
#undef RESULT_DIMS_param
#undef RESULT_DIMS

template<typename T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class D)>
struct supports_multiplies<array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, D)>, T> : std::true_type{};

template<typename T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class D)>
struct multiplies_result_type<array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, D)>, T>
{
	typedef array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, D)> type;
};

template<typename T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class D)>
struct supports_multiplies<T, array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, D)> > : std::true_type{};

template<typename T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class D)>
struct multiplies_result_type<T, array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, D)> >
{
	typedef array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, D)> type;
};

template<typename T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class DX), class DY>
struct supports_divides<array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, DX)>, quantity<T, DY> > : std::true_type{};

#define RESULT_DIMS_param(z, n, unused) typename array_dim_sub_dimensions<DX##n, DY>::type
#define RESULT_DIMS BOOST_PP_ENUM(MAX_ARRAY_DIM_SIZE, RESULT_DIMS_param, ~)
template<typename T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class DX), class DY>
struct divides_result_type<array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, DX)>, quantity<T, DY> >
{
	typedef array_dim_quantity<T, RESULT_DIMS> type;
};
#undef RESULT_DIMS_param
#undef RESULT_DIMS

template<typename T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class D)>
struct supports_divides<array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, D)>, T> : std::true_type{};

template<typename T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class D)>
struct divides_result_type<array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, D)>, T>
{
	typedef array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, D)> type;
};

template<typename T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class DX), BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class DY)>
struct supports_component_product<
	array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, DX)>,
	array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, DY)>
> : std::true_type{};

#define RESULT_DIMS_param(z, n, unused) typename array_dim_add_dimensions<DX##n, DY##n>::type
#define RESULT_DIMS BOOST_PP_ENUM(MAX_ARRAY_DIM_SIZE, RESULT_DIMS_param, ~)
template<typename T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class DX), BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class DY)>
struct component_product_result_type<
	array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, DX)>,
	array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, DY)>
>{
	typedef array_dim_quantity<T, RESULT_DIMS> type;
};
#undef RESULT_DIMS_param
#undef RESULT_DIMS

template<typename T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class D)>
struct has_data_type<array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, D)> > : std::true_type{};

template<typename T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class D)>
struct get_scalar_type<array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, D)> >
{
	typedef T type;
};

template<typename T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, class D)>
struct is_quantity_value<array_dim_quantity<T, BOOST_PP_ENUM_PARAMS(MAX_ARRAY_DIM_SIZE, D)> > : std::true_type{};

_KIAM_MATH_END

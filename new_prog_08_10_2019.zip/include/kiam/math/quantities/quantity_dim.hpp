#pragma once

_KIAM_MATH_BEGIN

template<int N1, int N2, int N3, int N4, int N5, int N6, int N7>
struct quantity_dim
{
	typedef quantity_dim type;

	static const int value1 = N1;
	static const int value2 = N2;
	static const int value3 = N3;
	static const int value4 = N4;
	static const int value5 = N5;
	static const int value6 = N6;
	static const int value7 = N7;
};

template<class D1, class D2>
struct add_dimensions;

template<
	int N1, int N2, int N3, int N4, int N5, int N6, int N7,
	int M1, int M2, int M3, int M4, int M5, int M6, int M7
>
struct add_dimensions
<
	quantity_dim<N1, N2, N3, N4, N5, N6, N7>,
	quantity_dim<M1, M2, M3, M4, M5, M6, M7>
>
{
	typedef quantity_dim<N1 + M1, N2 + M2, N3 + M3, N4 + M4, N5 + M5, N6 + M6, N7 + M7> type;
};

template<class D1, class D2>
struct sub_dimensions;

template<
	int N1, int N2, int N3, int N4, int N5, int N6, int N7,
	int M1, int M2, int M3, int M4, int M5, int M6, int M7
>
struct sub_dimensions
<
	quantity_dim<N1, N2, N3, N4, N5, N6, N7>,
	quantity_dim<M1, M2, M3, M4, M5, M6, M7>
>
{
	typedef quantity_dim<N1 - M1, N2 - M2, N3 - M3, N4 - M4, N5 - M5, N6 - M6, N7 - M7> type;
};

template<class D1, class D2, bool add>
struct calc_dimension;

template<class D1, class D2>
struct calc_dimension<D1, D2, true> : add_dimensions<D1, D2>{};

template<class D1, class D2>
struct calc_dimension<D1, D2, false> : sub_dimensions<D1, D2>{};

template<class D>
struct negate_dimension;

template<int N1, int N2, int N3, int N4, int N5, int N6, int N7>
struct negate_dimension<quantity_dim<N1, N2, N3, N4, N5, N6, N7> >
{
	typedef quantity_dim<-N1, -N2, -N3, -N4, -N5, -N6, -N7> type;
};

// Base dimensions
typedef quantity_dim<1,0,0,0,0,0,0> mass;
typedef quantity_dim<0,1,0,0,0,0,0> length;
typedef quantity_dim<0,0,1,0,0,0,0> time;
typedef quantity_dim<0,0,0,1,0,0,0> current;
typedef quantity_dim<0,0,0,0,1,0,0> temperature;
typedef quantity_dim<0,0,0,0,0,1,0> intensity;
typedef quantity_dim<0,0,0,0,0,0,1> angle;

typedef quantity_dim<0,2,0,0,0,0,0> area;			// l2
typedef quantity_dim<0,3,0,0,0,0,0> volume;			// l3
typedef quantity_dim<0,1,-1,0,0,0,0> velocity;		// l/t
typedef quantity_dim<0,1,-2,0,0,0,0> acceleration;	// l/(t2)
typedef quantity_dim<1,1,-1,0,0,0,0> momentum;		// ml/t
typedef quantity_dim<1,1,-2,0,0,0,0> force;			// ml/(t2)
typedef quantity_dim<1,2,-2,0,0,0,0> energy;		// m(l2)/(t2)
typedef energy work;
typedef quantity_dim<1,2,-3,0,0,0,0> power;			// m(l2)/(t3)
typedef quantity_dim<1,-1,-2,0,0,0,0> pressure;		// m/l(t2)
typedef quantity_dim<1,-3,0,0,0,0,0> density;		// m/(l3)
typedef quantity_dim<1,-1,-1,0,0,0,0> viscosity;	// m/lt
typedef quantity_dim<0,0,1,1,0,0,0> charge;			// tA
typedef quantity_dim<1,2,-3,-1,0,0,0> voltage;		// m(l2)/(t3)A
typedef quantity_dim<1,2,-3,-2,0,0,0> resistance;	// m(l2)/(t3)(A2)
typedef quantity_dim<-1,-2,4,2,0,0,0> capacitance;	// (t4)(A2)/m(l2)
typedef quantity_dim<1,0,-2,-1,0,0,0> induction;	// m/(t2)A
typedef quantity_dim<1,2,-2,-2,0,0,0> inductance;	// m(l2)/(t2)(A2)
typedef quantity_dim<1,2,-2,0,-1,0,0> heat;			// m(l2)/(t2)K
typedef quantity_dim<0,2,-2,0,-1,0,0> specific_heat; // (l2)/(t2)K

typedef quantity_dim<0,0,0,0,0,0,0> scalar;

_KIAM_MATH_END

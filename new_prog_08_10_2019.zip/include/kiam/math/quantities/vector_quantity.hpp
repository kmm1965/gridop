#pragma once

#include "quantity.hpp"

_KIAM_MATH_BEGIN

template<class T, class Dimensions>
struct vector_quantity
{
	typedef vector_quantity type;
	typedef T data_type;
	typedef data_type &reference;
	typedef Dimensions dim;
	typedef quantity<data_type, dim> quantity_type;
	typedef quantity<data_type, typename add_dimensions<dim, dim>::type> quantity_type2;

	__DEVICE __HOST
	vector_quantity() : m_value_x(data_type()), m_value_y(data_type()), m_value_z(data_type()){}

	__DEVICE __HOST
	vector_quantity(data_type x, data_type y, data_type z) : m_value_x(x), m_value_y(y), m_value_z(z){}

	__DEVICE __HOST
	vector_quantity(quantity_type x, quantity_type y, quantity_type z) : m_value_x(x.value()), m_value_y(y.value()), m_value_z(z.value()){}

	__DEVICE __HOST
	vector_quantity(const vector_quantity &rhs) : m_value_x(rhs.value_x()), m_value_y(rhs.value_y()), m_value_z(rhs.value_z()){}

	__DEVICE __HOST
	data_type value_x() const { return m_value_x; }

	__DEVICE __HOST
	data_type value_y() const { return m_value_y; }

	__DEVICE __HOST
	data_type value_z() const { return m_value_z; }

	__DEVICE __HOST
	reference value_x(){ return m_value_x; }

	__DEVICE __HOST
	reference value_y(){ return m_value_y; }

	__DEVICE __HOST
	reference value_z(){ return m_value_z; }

	__DEVICE __HOST
	quantity_type qvalue_x() const { return quantity_type(m_value_x); }

	__DEVICE __HOST
	quantity_type qvalue_y() const { return quantity_type(m_value_y); }

	__DEVICE __HOST
	quantity_type qvalue_z() const { return quantity_type(m_value_z); }

	__DEVICE __HOST
	void qvalue_x(quantity_type value){ m_value_x = value.value(); }

	__DEVICE __HOST
	void qvalue_y(quantity_type value){ m_value_y = value.value(); }

	__DEVICE __HOST
	void qvalue_z(quantity_type value){ m_value_z = value.value(); }

	__DEVICE __HOST
	quantity_type2 qvalue_xy() const { return quantity_type2(m_value_x * m_value_y); }

	__DEVICE __HOST
	quantity_type2 qvalue_xz() const { return quantity_type2(m_value_x * m_value_z); }

	__DEVICE __HOST
	quantity_type2 qvalue_yz() const { return quantity_type2(m_value_y * m_value_z); }

	__DEVICE __HOST
	vector_quantity& operator+=(const vector_quantity &rhs)
	{
		m_value_x += rhs.value_x();
		m_value_y += rhs.value_y();
		m_value_z += rhs.value_z();
		return *this;
	}

	__DEVICE __HOST
	vector_quantity& operator-=(const vector_quantity &rhs)
	{
		m_value_x -= rhs.value_x();
		m_value_y -= rhs.value_y();
		m_value_z -= rhs.value_z();
		return *this;
	}

	__DEVICE __HOST
	vector_quantity& operator*=(data_type rhs)
	{
		m_value_x *= rhs;
		m_value_y *= rhs;
		m_value_z *= rhs;
		return *this;
	}

	__DEVICE __HOST
	vector_quantity& operator/=(data_type rhs)
	{
		m_value_x /= rhs;
		m_value_y /= rhs;
		m_value_z /= rhs;
		return *this;
	}

	__DEVICE __HOST
	vector_quantity& operator*=(const quantity<data_type, scalar> &rhs)
	{
		m_value_x *= rhs.value();
		m_value_y *= rhs.value();
		m_value_z *= rhs.value();
		return *this;
	}

	__DEVICE __HOST
	vector_quantity& operator/=(const quantity<data_type, scalar> &rhs)
	{
		m_value_x /= rhs.value();
		m_value_y /= rhs.value();
		m_value_z /= rhs.value();
		return *this;
	}

	__DEVICE __HOST
	quantity_type length() const {
		return quantity_type(func::sqrt(m_value_x * m_value_x + m_value_y * m_value_y + m_value_z * m_value_z));
	}

	__DEVICE __HOST
	vector_quantity operator-() const {
		return vector_quantity(-m_value_x, -m_value_y, -m_value_z);
	}

	__DEVICE __HOST
	quantity<data_type, typename add_dimensions<dim, dim>::type> sqr() const {
		return *this & *this;
	}

	__DEVICE __HOST
	quantity_type abs() const {
		return length();
	}

	__DEVICE __HOST
	quantity_type sum_abs() const {
		return quantity_type(func::abs(m_value_x) + func::abs(m_value_y) + func::abs(m_value_z));
	}

	__DEVICE __HOST
	bool operator==(const vector_quantity &rhs) const {
		return m_value_x == rhs.value_x() && m_value_y == rhs.value_y() && m_value_z == rhs.value_z();
	}

	__DEVICE __HOST
	bool operator!=(const vector_quantity &rhs) const {
		return m_value_x != rhs.value_x() || m_value_y != rhs.value_y() || m_value_z != rhs.value_z();
	}

private:
	data_type m_value_x, m_value_y, m_value_z;
};

template<class T, class D>
__DEVICE __HOST
vector_quantity<T, D> operator+(const vector_quantity<T, D> &x, const vector_quantity<T, D> &y){
	return vector_quantity<T, D>(x.value_x() + y.value_x(), x.value_y() + y.value_y(), x.value_z() + y.value_z());
}

template<class T, class D>
__DEVICE __HOST
vector_quantity<T, D> operator-(const vector_quantity<T, D> &x, const vector_quantity<T, D> &y){
	return vector_quantity<T, D>(x.value_x() - y.value_x(), x.value_y() - y.value_y(), x.value_z() - y.value_z());
}

template<class T, class D1, class D2>
__DEVICE __HOST
vector_quantity<T, typename add_dimensions<D1, D2>::type>
operator*(const vector_quantity<T, D1> &x, const quantity<T, D2> &y)
{
	typedef typename add_dimensions<D1, D2>::type dim;
	return vector_quantity<T, dim>(
		x.value_x() * y.value(), x.value_y() * y.value(), x.value_z() * y.value());
}

template<class T, class D1, class D2>
__DEVICE __HOST
vector_quantity<T, typename add_dimensions<D1, D2>::type>
operator*(const quantity<T, D1> &x, const vector_quantity<T, D2> &y)
{
	typedef typename add_dimensions<D1, D2>::type dim;
	return vector_quantity<T, dim>(
		x.value() * y.value_x(), x.value() * y.value_y(), x.value() * y.value_z());
}

template<class T, class D1, class D2>
__DEVICE __HOST
vector_quantity<T, typename sub_dimensions<D1, D2>::type>
operator/(const vector_quantity<T, D1> &x, const quantity<T, D2> &y)
{
	typedef typename sub_dimensions<D1, D2>::type dim;
	return vector_quantity<T, dim>(
		x.value_x() / y.value(), x.value_y() / y.value(), x.value_z() / y.value());
}

template<class T, class D>
__DEVICE __HOST
vector_quantity<T, D> operator*(const vector_quantity<T, D> &x, T y){
	return vector_quantity<T, D>(x.value_x() * y, x.value_y() * y, x.value_z() * y);
}

template<class T, class D>
__DEVICE __HOST
vector_quantity<T, D> operator*(T x, const vector_quantity<T, D> &y){
	return vector_quantity<T, D>(x * y.value_x(), x * y.value_y(), x * y.value_z());
}

template<class T, class D>
__DEVICE __HOST
vector_quantity<T, D> operator/(const vector_quantity<T, D> &x, T y){
	return vector_quantity<T, D>(x.value_x() / y, x.value_y() / y, x.value_z() / y);
}

// ��������� ������������
template<class T, class D1, class D2>
__DEVICE __HOST
vector_quantity<
	T,
	typename add_dimensions<D1, D2>::type // new dimensions
>
operator*(const vector_quantity<T, D1> &x, const vector_quantity<T, D2> &y)
{
	typedef typename add_dimensions<D1, D2>::type dim;
	return vector_quantity<T, dim>(
		x.value_y() * y.value_z() - x.value_z() * y.value_y(),
		x.value_x() * y.value_z() - x.value_z() * y.value_x(),
		x.value_x() * y.value_y() - x.value_y() * y.value_x());
}

// ��������� ������������
template<class T, class D1, class D2>
__DEVICE __HOST
quantity<T, typename add_dimensions<D1, D2>::type>
operator&(const vector_quantity<T, D1> &x, const vector_quantity<T, D2> &y)
{
	typedef typename add_dimensions<D1, D2>::type dim;
	return quantity<T, dim>(x.value_x() * y.value_x() + x.value_y() * y.value_y() + x.value_z() * y.value_z());
}

// �������������� ������������
template<class T, class D1, class D2>
__DEVICE __HOST
vector_quantity<T, typename add_dimensions<D1, D2>::type>
operator^(const vector_quantity<T, D1> &x, const vector_quantity<T, D2> &y)
{
	typedef typename add_dimensions<D1, D2>::type dim;
	return vector_quantity<T, dim>(
		x.value_x() * y.value_x(),
		x.value_y() * y.value_y(),
		x.value_z() * y.value_z());
}

template <class T> struct is_vector_quantity : std::false_type {};
template <class T> struct is_vector_quantity<const T> : is_vector_quantity<T>{};
template <class T> struct is_vector_quantity<volatile const T> : is_vector_quantity<T>{};
template <class T> struct is_vector_quantity<volatile T> : is_vector_quantity<T>{};
template<typename T, class D> struct is_vector_quantity<vector_quantity<T, D> > : std::true_type{};

template<typename T, class D1, class D2>
struct supports_multiplies<vector_quantity<T, D1>, vector_quantity<T, D2> > : std::true_type{};

template<typename T, class D1, class D2>
struct multiplies_result_type<vector_quantity<T, D1>, vector_quantity<T, D2> >
{
	typedef typename add_dimensions<D1, D2>::type dim;
	typedef vector_quantity<T, dim> type;
};

template<typename T, class D1, class D2>
struct supports_multiplies<vector_quantity<T, D1>, quantity<T, D2> > : std::true_type{};

template<typename T, class D1, class D2>
struct multiplies_result_type<vector_quantity<T, D1>, quantity<T, D2> >
{
	typedef typename add_dimensions<D1, D2>::type dim;
	typedef vector_quantity<T, dim> type;
};

template<typename T, class D1, class D2>
struct supports_multiplies<quantity<T, D1>, vector_quantity<T, D2> > : std::true_type{};

template<typename T, class D1, class D2>
struct multiplies_result_type<quantity<T, D1>, vector_quantity<T, D2> >
{
	typedef typename add_dimensions<D1, D2>::type dim;
	typedef vector_quantity<T, dim> type;
};

template<typename T, class D>
struct supports_multiplies<vector_quantity<T, D>, T> : std::true_type{};

template<typename T, class D>
struct multiplies_result_type<vector_quantity<T, D>, T>
{
	typedef vector_quantity<T, D> type;
};

template<typename T, class D>
struct supports_multiplies<T, vector_quantity<T, D> > : std::true_type{};

template<typename T, class D>
struct multiplies_result_type<T, vector_quantity<T, D> >
{
	typedef vector_quantity<T, D> type;
};

template<typename T, class D1, class D2>
struct supports_divides<vector_quantity<T, D1>, quantity<T, D2> > : std::true_type{};

template<typename T, class D1, class D2>
struct divides_result_type<vector_quantity<T, D1>, quantity<T, D2> >
{
	typedef typename sub_dimensions<D1, D2>::type dim;
	typedef vector_quantity<T, dim> type;
};

template<typename T, class D>
struct supports_divides<vector_quantity<T, D>, T> : std::true_type{};

template<typename T, class D>
struct divides_result_type<vector_quantity<T, D>, T>
{
	typedef vector_quantity<T, D> type;
};

template<typename T, class D1, class D2>
struct supports_scalar_product<vector_quantity<T, D1>, vector_quantity<T, D2> > : std::true_type{};

template<typename T, class D1, class D2>
struct scalar_product_result_type<vector_quantity<T, D1>, vector_quantity<T, D2> >
{
	typedef typename add_dimensions<D1, D2>::type dim;
	typedef quantity<T, dim> type;
};

template<typename T, class D1, class D2>
struct supports_component_product<vector_quantity<T, D1>, vector_quantity<T, D2> > : std::true_type{};

template<typename T, class D1, class D2>
struct component_product_result_type<vector_quantity<T, D1>, vector_quantity<T, D2> >
{
	typedef typename add_dimensions<D1, D2>::type dim;
	typedef vector_quantity<T, dim> type;
};

template<typename T, class D>
struct has_data_type<vector_quantity<T, D> > : std::true_type{};

template<typename T, class D>
struct get_scalar_type<vector_quantity<T, D> >
{
	typedef T type;
};

template<typename T, class D>
struct is_quantity_value<vector_quantity<T, D> > : std::true_type{};

_KIAM_MATH_END

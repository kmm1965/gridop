#pragma once

#include "quantity_dim.hpp"

_KIAM_MATH_BEGIN

template<class T, class Dimensions, unsigned N>
struct array_quantity
{
	typedef array_quantity type;
	typedef T data_type;
	typedef data_type *pointer;
	typedef const data_type *const_pointer;
	typedef data_type &reference;
	typedef const data_type &const_reference;
	typedef Dimensions dim;
	static const unsigned array_size = N;
	typedef quantity<data_type, dim> quantity_type;

	__DEVICE __HOST
	array_quantity(){
		fill_n(m_values, array_size, data_type());
	}

	__DEVICE __HOST
	array_quantity(const array_quantity &rhs){
		copy(rhs.m_values, rhs.m_values + array_size, m_values);
	}

	__DEVICE __HOST
	pointer values(){ return m_values; }

	__DEVICE __HOST
	const_pointer values() const { return m_values; }

	__DEVICE __HOST
	data_type operator[](unsigned i) const { return m_values[i]; }

	__DEVICE __HOST
	reference operator[](unsigned i){ return m_values[i]; }

	__DEVICE __HOST
	quantity_type qvalue(unsigned i) const { return quantity_type(m_values[i]); }

	__DEVICE __HOST
	void qvalue(unsigned i, quantity_type value){ m_values[i] = value.value(); }

	__DEVICE __HOST
	array_quantity& operator+=(const array_quantity &rhs)
	{
		transform_n(m_values, rhs.m_values, array_size, m_values, plus<data_type>());
		return *this;
	}

	__DEVICE __HOST
	array_quantity& operator-=(const array_quantity &rhs)
	{
		transform_n(m_values, rhs.m_values, array_size, m_values, minus<data_type>());
		return *this;
	}

	__DEVICE __HOST
	array_quantity& operator*=(data_type rhs)
	{
		transform_n(m_values, array_size, m_values, math_bind2nd(multiplies<data_type>(), rhs));
		return *this;
	}

	__DEVICE __HOST
	array_quantity& operator/=(data_type rhs)
	{
		transform_n(m_values, array_size, m_values, math_bind2nd(divides<data_type>(), rhs));
		return *this;
	}

	__DEVICE __HOST
	array_quantity& operator*=(const quantity<data_type, scalar> &rhs)
	{
		transform_n(m_values, array_size, m_values, math_bind2nd(multiplies<data_type>(), rhs.value()));
		return *this;
	}

	__DEVICE __HOST
	array_quantity& operator/=(const quantity<data_type, scalar> &rhs)
	{
		transform_n(m_values, array_size, m_values, math_bind2nd(divides<data_type>(), rhs.value()));
		return *this;
	}

	__DEVICE __HOST
	quantity_type length() const {
		return quantity_type(func::sqrt(math_inner_product(m_values, m_values + array_size, m_values)));
	}

	__DEVICE __HOST
	array_quantity operator-() const
	{
		array_quantity result;
		transform_n(m_values, array_size, result.m_values, negate<data_type>());
		return result;
	}

	__DEVICE __HOST
	quantity<data_type, typename add_dimensions<dim, dim>::type> sqr() const {
		return *this & *this;
	}

	__DEVICE __HOST
	quantity_type abs() const {
		return length();
	}

	__DEVICE __HOST
	bool operator==(const array_quantity &rhs) const {
		return math_inner_product(m_values, m_values + array_size, rhs.m_values, true, logical_and<bool>(), equal_to<data_type>());
	}

	__DEVICE __HOST
	bool operator!=(const array_quantity &rhs) const {
		return math_inner_product(m_values, m_values + array_size, rhs.m_values, false, logical_or<bool>(), not_equal_to<data_type>());
	}

private:
	data_type m_values[array_size];
};

template<class T, class D, unsigned N>
__DEVICE __HOST
array_quantity<T, D, N> operator+(const array_quantity<T, D, N> &x, const array_quantity<T, D, N> &y)
{
	array_quantity<T, D, N> result;
	transform_n(x.values(), y.values(), N, result.values(), plus<T>());
	return result;
}

template<class T, class D, unsigned N>
__DEVICE __HOST
array_quantity<T, D, N> operator-(const array_quantity<T, D, N> &x, const array_quantity<T, D, N> &y)
{
	array_quantity<T, D, N> result;
	transform_n(x.values(), y.values(), N, result.values(), minus<T>());
	return result;
}

template<class T, class D1, class D2, unsigned N>
__DEVICE __HOST
array_quantity<T, typename add_dimensions<D1, D2>::type, N>
operator*(const array_quantity<T, D1, N> &x, const quantity<T, D2> &y)
{
	typedef typename add_dimensions<D1, D2>::type dim;
	array_quantity<T, dim, N> result;
	transform_n(x.values(), N, result.values(), math_bind2nd(multiplies<T>(), y.value()));
	return result;
}

template<class T, class D1, class D2, unsigned N>
__DEVICE __HOST
array_quantity<T, typename add_dimensions<D1, D2>::type, N>
operator*(const quantity<T, D1> &x, const array_quantity<T, D2, N> &y)
{
	typedef typename add_dimensions<D1, D2>::type dim;
	array_quantity<T, dim, N> result;
	transform_n(y.values(), N, result.values(), math_bind1st(multiplies<T>(), x.value()));
	return result;
}

template<class T, class D1, class D2, unsigned N>
__DEVICE __HOST
array_quantity<T, typename sub_dimensions<D1, D2>::type, N>
operator/(const array_quantity<T, D1, N> &x, const quantity<T, D2> &y)
{
	typedef typename sub_dimensions<D1, D2>::type dim;
	array_quantity<T, dim, N> result;
	transform_n(x.values(), N, result.values(), math_bind2nd(divides<T>(), y.value()));
	return result;
}

template<class T, class D, unsigned N>
__DEVICE __HOST
array_quantity<T, D, N> operator*(const array_quantity<T, D, N> &x, T y)
{
	array_quantity<T, D, N> result;
	transform_n(x.values(), N, result.values(), math_bind2nd(multiplies<T>(), y));
	return result;
}

template<class T, class D, unsigned N>
__DEVICE __HOST
array_quantity<T, D, N> operator*(T x, const array_quantity<T, D, N> &y)
{
	array_quantity<T, D, N> result;
	transform_n(y.values(), N, result.values(), math_bind1st(multiplies<T>(), x));
	return result;
}

template<class T, class D, unsigned N>
__DEVICE __HOST
array_quantity<T, D, N> operator/(const array_quantity<T, D, N> &x, T y)
{
	array_quantity<T, D, N> result;
	transform_n(x.values(), N, result.values(), math_bind2nd(divides<T>(), y));
	return result;
}

// ��������� ������������
template<class T, class D1, class D2, unsigned N>
__DEVICE __HOST
quantity<T, typename add_dimensions<D1, D2>::type>
operator&(const array_quantity<T, D1, N> &x, const array_quantity<T, D2, N> &y)
{
	typedef typename add_dimensions<D1, D2>::type dim;
	return quantity<T, dim>(math_inner_product(x.values(), x.values() + N, y.values()));
}

// �������������� ������������
template<class T, class D1, class D2, unsigned N>
__DEVICE __HOST
array_quantity<T, typename add_dimensions<D1, D2>::type, N>
operator^(const array_quantity<T, D1, N> &x, const array_quantity<T, D2, N> &y)
{
	typedef typename add_dimensions<D1, D2>::type dim;
	array_quantity<T, dim, N> result;
	transform_n(x.values(), y.values(), N, result.values(), multiplies<T>());
	return result;
}

template <class T> struct is_array_quantity : std::false_type {};
template <class T> struct is_array_quantity<const T> : is_array_quantity<T>{};
template <class T> struct is_array_quantity<volatile const T> : is_array_quantity<T>{};
template <class T> struct is_array_quantity<volatile T> : is_array_quantity<T>{};
template<typename T, class D, unsigned N> struct is_array_quantity<array_quantity<T, D, N> > : std::true_type{};

template<typename T, class D1, class D2, unsigned N>
struct supports_multiplies<array_quantity<T, D1, N>, quantity<T, D2> > : std::true_type{};

template<typename T, class D1, class D2, unsigned N>
struct multiplies_result_type<array_quantity<T, D1, N>, quantity<T, D2> >
{
	typedef typename add_dimensions<D1, D2>::type dim;
	typedef array_quantity<T, dim, N> type;
};

template<typename T, class D1, class D2, unsigned N>
struct supports_multiplies<quantity<T, D1>, array_quantity<T, D2, N> > : std::true_type{};

template<typename T, class D1, class D2, unsigned N>
struct multiplies_result_type<quantity<T, D1>, array_quantity<T, D2, N> >
{
	typedef typename add_dimensions<D1, D2>::type dim;
	typedef array_quantity<T, dim, N> type;
};

template<typename T, class D, unsigned N>
struct supports_multiplies<array_quantity<T, D, N>, T> : std::true_type{};

template<typename T, class D, unsigned N>
struct multiplies_result_type<array_quantity<T, D, N>, T>
{
	typedef D dim;
	typedef array_quantity<T, dim, N> type;
};

template<typename T, class D, unsigned N>
struct supports_multiplies<T, array_quantity<T, D, N> > : std::true_type{};

template<typename T, class D, unsigned N>
struct multiplies_result_type<T, array_quantity<T, D, N> >
{
	typedef D dim;
	typedef array_quantity<T, dim, N> type;
};

template<typename T, class D1, class D2, unsigned N>
struct supports_divides<array_quantity<T, D1, N>, quantity<T, D2> > : std::true_type{};

template<typename T, class D1, class D2, unsigned N>
struct divides_result_type<array_quantity<T, D1, N>, quantity<T, D2> >
{
	typedef typename sub_dimensions<D1, D2>::type dim;
	typedef array_quantity<T, dim, N> type;
};

template<typename T, class D, unsigned N>
struct supports_divides<array_quantity<T, D, N>, T> : std::true_type{};

template<typename T, class D, unsigned N>
struct divides_result_type<array_quantity<T, D, N>, T>
{
	typedef D dim;
	typedef array_quantity<T, dim, N> type;
};

template<typename T, class D1, class D2, unsigned N>
struct supports_scalar_product<array_quantity<T, D1, N>, array_quantity<T, D2, N> > : std::true_type{};

template<typename T, class D1, class D2, unsigned N>
struct scalar_product_result_type<array_quantity<T, D1, N>, array_quantity<T, D2, N> >
{
	typedef typename add_dimensions<D1, D2>::type dim;
	typedef quantity<T, dim> type;
};

template<typename T, class D1, class D2, unsigned N>
struct supports_component_product<array_quantity<T, D1, N>, array_quantity<T, D2, N> > : std::true_type{};

template<typename T, class D1, class D2, unsigned N>
struct component_product_result_type<array_quantity<T, D1, N>, array_quantity<T, D2, N> >
{
	typedef typename add_dimensions<D1, D2>::type dim;
	typedef array_quantity<T, dim, N> type;
};

template<typename T, class D, unsigned N>
struct has_data_type<array_quantity<T, D, N> > : std::true_type{};

template<typename T, class D, unsigned N>
struct get_scalar_type<array_quantity<T, D, N> >
{
	typedef T type;
};

template<typename T, class D, unsigned N>
struct is_quantity_value<array_quantity<T, D, N> > : std::true_type{};

_KIAM_MATH_END

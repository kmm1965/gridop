#pragma once

#include "quantity_dim.hpp"

_KIAM_MATH_BEGIN

template<typename T, class Dimensions>
struct quantity
{
	typedef quantity type;
	typedef T data_type;
	typedef Dimensions dim;

	__DEVICE __HOST
	explicit quantity(data_type x = data_type()) : m_value(x){}

	__DEVICE __HOST
	quantity(const quantity &rhs) : m_value(rhs.value()){}

	__DEVICE __HOST
	quantity& operator=(const quantity &rhs)
	{
		m_value = rhs.value();
		return *this;
	}

	__DEVICE __HOST
	data_type value() const { return m_value; }

	__DEVICE __HOST
	quantity& operator+=(const quantity &rhs)
	{
		m_value += rhs.value();
		return *this;
	}

	__DEVICE __HOST
	quantity& operator-=(const quantity &rhs)
	{
		m_value -= rhs.value();
		return *this;
	}

	__DEVICE __HOST
	quantity& operator*=(data_type rhs)
	{
		m_value *= rhs;
		return *this;
	}

	__DEVICE __HOST
	quantity& operator/=(data_type rhs)
	{
		m_value /= rhs;
		return *this;
	}

	__DEVICE __HOST
	quantity& operator*=(const quantity<data_type, scalar> &rhs)
	{
		m_value *= rhs.value();
		return *this;
	}

	__DEVICE __HOST
	quantity& operator/=(const quantity<data_type, scalar> &rhs)
	{
		m_value /= rhs.value();
		return *this;
	}

	__DEVICE __HOST
	quantity operator-() const {
		return quantity(-m_value);
	}

	__DEVICE __HOST
	quantity<data_type, typename add_dimensions<dim, dim>::type> sqr() const {
		return *this * *this;
	}

	__DEVICE __HOST
	quantity<data_type,
		quantity_dim<
			dim::value1 / 2,
			dim::value2 / 2,
			dim::value3 / 2,
			dim::value4 / 2,
			dim::value5 / 2,
			dim::value6 / 2,
			dim::value7 / 2
		>
	> sqrt() const
	{
		MATH_STATIC_ASSERT(dim::value1 % 2 == 0);
		MATH_STATIC_ASSERT(dim::value2 % 2 == 0);
		MATH_STATIC_ASSERT(dim::value3 % 2 == 0);
		MATH_STATIC_ASSERT(dim::value4 % 2 == 0);
		MATH_STATIC_ASSERT(dim::value5 % 2 == 0);
		MATH_STATIC_ASSERT(dim::value6 % 2 == 0);
		MATH_STATIC_ASSERT(dim::value7 % 2 == 0);
		return quantity<data_type,
			quantity_dim<
				dim::value1 / 2,
				dim::value2 / 2,
				dim::value3 / 2,
				dim::value4 / 2,
				dim::value5 / 2,
				dim::value6 / 2,
				dim::value7 / 2
			>
		>(func::sqrt(m_value));
	}

	__DEVICE __HOST
	quantity abs() const {
		return quantity(m_value < 0 ? -m_value : m_value);
	}

	__DEVICE __HOST
	bool operator==(const quantity &rhs) const {
		return m_value == rhs.value();
	}

	__DEVICE __HOST
	bool operator!=(const quantity &rhs) const {
		return m_value != rhs.value();
	}

	__DEVICE __HOST
	bool operator<(const quantity &rhs) const {
		return m_value < rhs.value();
	}

	__DEVICE __HOST
	bool operator<=(const quantity &rhs) const {
		return m_value <= rhs.value();
	}

	__DEVICE __HOST
	bool operator>(const quantity &rhs) const {
		return m_value > rhs.value();
	}

	__DEVICE __HOST
	bool operator>=(const quantity &rhs) const {
		return m_value >= rhs.value();
	}

private:
	data_type m_value;
};

template<typename T, class D>
__DEVICE __HOST
quantity<T, D> operator+(const quantity<T, D> &x, const quantity<T, D> &y){
	return quantity<T, D>(x.value() + y.value());
}

template<typename T, class D>
__DEVICE __HOST
quantity<T, D> operator-(const quantity<T, D> &x, const quantity<T, D> &y){
	return quantity<T, D>(x.value() - y.value());
}

template<typename T, class D1, class D2>
__DEVICE __HOST
quantity<T, typename add_dimensions<D1, D2>::type>
operator*(const quantity<T, D1> &x, const quantity<T, D2> &y)
{
	typedef typename add_dimensions<D1, D2>::type dim;
	return quantity<T, dim>(x.value() * y.value());
}

template<typename T, class D1, class D2>
__DEVICE __HOST
quantity<T, typename sub_dimensions<D1, D2>::type>
operator/(const quantity<T, D1> &x, const quantity<T, D2> &y)
{
	typedef typename sub_dimensions<D1, D2>::type dim;
	return quantity<T, dim>(x.value() / y.value());
}

template<typename T, class D>
__DEVICE __HOST
quantity<T, D> operator*(const quantity<T, D> &x, T y){
	return quantity<T, D>(x.value() * y);
}

template<typename T, class D>
__DEVICE __HOST
quantity<T, D> operator*(T x, const quantity<T, D> &y){
	return quantity<T, D>(x * y.value());
}

template<typename T, class D>
__DEVICE __HOST
quantity<T, D> operator/(const quantity<T, D> &x, T y){
	return quantity<T, D>(x.value() / y);
}

template<typename T, class D>
__DEVICE __HOST
quantity<T, typename negate_dimension<D>::type>
operator/(T x, const quantity<T, D> &y){
	return quantity<T, typename negate_dimension<D>::type>(x / y.value());
}

template <class T> struct is_quantity : std::false_type {};
template <class T> struct is_quantity<const T> : is_quantity<T>{};
template <class T> struct is_quantity<volatile const T> : is_quantity<T>{};
template <class T> struct is_quantity<volatile T> : is_quantity<T>{};
template<typename T, class D> struct is_quantity<quantity<T, D> > : std::true_type{};

template<typename T, class D1, class D2>
struct supports_multiplies<quantity<T, D1>, quantity<T, D2> > : std::true_type{};

template<typename T, class D1, class D2>
struct multiplies_result_type<quantity<T, D1>, quantity<T, D2> >
{
	typedef typename add_dimensions<D1, D2>::type dim;
	typedef quantity<T, dim> type;
};

template<typename T, class D>
struct supports_multiplies<quantity<T, D>, T> : std::true_type{};

template<typename T, class D>
struct multiplies_result_type<quantity<T, D>, T>
{
	typedef quantity<T, D> type;
};

template<typename T, class D>
struct supports_multiplies<T, quantity<T, D> > : std::true_type{};

template<typename T, class D>
struct multiplies_result_type<T, quantity<T, D> >
{
	typedef quantity<T, D> type;
};

template<typename T, class D1, class D2>
struct supports_divides<quantity<T, D1>, quantity<T, D2> > : std::true_type{};

template<typename T, class D1, class D2>
struct divides_result_type<quantity<T, D1>, quantity<T, D2> >
{
	typedef typename sub_dimensions<D1, D2>::type dim;
	typedef quantity<T, dim> type;
};

template<typename T, class D>
struct supports_divides<quantity<T, D>, T> : std::true_type{};

template<typename T, class D>
struct divides_result_type<quantity<T, D>, T>
{
	typedef quantity<T, D> type;
};

template<typename T, class D>
struct supports_divides<T, quantity<T, D> > : std::true_type{};

template<typename T, class D>
struct divides_result_type<T, quantity<T, D> >
{
	typedef typename negate_dimension<D>::type dim;
	typedef quantity<T, dim> type;
};

template<typename T, class D>
struct has_data_type<quantity<T, D> > : std::true_type{};

template<typename T, class D>
struct get_scalar_type<quantity<T, D> >
{
	typedef T type;
};

template<typename T, class D>
struct is_quantity_value<quantity<T, D> > : std::true_type{};

_KIAM_MATH_END

#pragma once

#include <utility>	// pair
#include <numeric>	// accumulate

_KIAM_MATH_BEGIN

template<typename T1, typename T2>
#ifdef DONT_USE_CXX_11
struct math_pair : std::pair<T1, T2>{};
#else
using math_pair = std::pair<T1, T2>;
#endif

template<class Operation, class Type>
std::binder1st<Operation> math_bind1st(const Operation& _Func, const Type &_Left){
	return std::bind1st(_Func, _Left);
}

template<class Operation, class Type>
std::binder2nd<Operation> math_bind2nd(const Operation& _Func, const Type &_Right){
	return std::bind2nd(_Func, _Right);
}

template<typename T> inline
void math_swap(T &x, T &y){
	std::swap(x, y);
}

template<class _FwdIt, class _Ty> inline
void math_fill(_FwdIt _First, _FwdIt _Last, const _Ty& _Val){
	std::fill(_First, _Last, _Val);
}

template<class _FwdIt, class _Ty> inline
void math_fill_n(_FwdIt _First, size_t n, const _Ty& _Val){
	std::fill_n(_First, n, _Val);
}

template<class _InIt, class _OutIt> inline
_OutIt math_copy(_InIt _First, _InIt _Last, _OutIt _Dest){
	return std::copy(_First, _Last, _Dest);
}

template<class _InIt, class _OutIt> inline
_OutIt math_copy_n(_InIt _First, size_t n, _OutIt _Dest){
	return math_copy(_First, _First + n, _Dest);
}

template<class _InIt, class _Ty, class _Fn2> inline
_Ty math_accumulate(_InIt _First, _InIt _Last, _Ty _Val, _Fn2 _Func){
	return std::accumulate(_First, _Last, _Val, _Func);
}

template<class _InIt, class _Ty, class _Fn2> inline
_Ty math_accumulate_n(_InIt _First, size_t n, _Ty _Val, _Fn2 _Func){
	return math_accumulate(_First, _First + n, _Val, _Func);
}

template<class _InIt, class _OutIt, class _Fn1> inline
_OutIt math_transform(_InIt _First, _InIt _Last, _OutIt _Dest, _Fn1 _Func){
	return std::transform(_First, _Last, _Dest, _Func);
}

template<class _InIt, class _OutIt, class _Fn1> inline
_OutIt math_transform_n(_InIt _First, size_t n, _OutIt _Dest, _Fn1 _Func){
	return math_transform(_First, _First + n, _Dest, _Func);
}

template<class _InIt1, class _InIt2, class _OutIt, class _Fn2> inline
_OutIt math_transform(_InIt1 _First1, _InIt1 _Last1, _InIt2 _First2, _OutIt _Dest, _Fn2 _Func){
	return std::transform(_First1, _Last1, _First2, _Dest, _Func);
}

template<class _InIt1, class _InIt2, class _OutIt, class _Fn2> inline
_OutIt math_transform_n(_InIt1 _First1, size_t n, _InIt2 _First2, _OutIt _Dest, _Fn2 _Func){
	return math_transform(_First1, _First1 + n, _First2, _Dest, _Func);
}

template<class _InIt1, class _InIt2, class _Ty, class _Fn21, class _Fn22> inline
_Ty math_inner_product(_InIt1 _First1, _InIt1 _Last1, _InIt2 _First2, _Ty _Val, _Fn21 _Func1, _Fn22 _Func2){
	return std::inner_product(_First1, _Last1, _First2, _Val, _Func1, _Func2);
}

template<class _InIt1, class _InIt2, class _Ty, class _Fn21, class _Fn22> inline
_Ty math_inner_product_n(_InIt1 _First1, size_t n, _InIt2 _First2, _Ty _Val, _Fn21 _Func1, _Fn22 _Func2){
	return math_inner_product(_First1, _First1 + n, _First2, _Val, _Func1, _Func2);
}

template<class _InIt1, class _InIt2, class _Ty> inline
_Ty math_inner_product(_InIt1 _First1, _InIt1 _Last1, _InIt2 _First2, _Ty _Val){
	return std::inner_product(_First1, _Last1, _First2, _Val);
}

template<class _InIt1, class _InIt2, class _Ty> inline
_Ty math_inner_product_n(_InIt1 _First1, size_t n, _InIt2 _First2, _Ty _Val){
	return math_inner_product(_First1, _First1 + n, _First2, _Val);
}

using math_string = std::string;

_KIAM_MATH_END

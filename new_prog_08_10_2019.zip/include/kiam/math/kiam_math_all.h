#pragma once

#include <cassert>

#include "kiam_math_alg.h"

#include <boost/preprocessor.hpp>

#include "math_def.h"
#include "kiam_math.h"
#include "binary_operator.hpp"
#include "composition_operator.hpp"
#include "host_vector.hpp"
#include "pinned_host_vector.hpp"
#include "vector_grid_function.hpp"
#include "computable_grid_function.hpp"
#include "generic_operators.hpp"
#include "type_traits.hpp"
#include "vector_type.hpp"
#include "array_value.hpp"
#include "dual.hpp"
#include "dual3.hpp"
#include "me_number.hpp"
#include "stride_iterator.hpp"
#include "quantities/quantities.hpp"
#include "math_array.hpp"
#include "math_shift.hpp"

#include "stride_iterator.hpp"
#include "matrix_stride_iterator.hpp"

#include "vector_proxy.hpp"
#include "meta_loop.hpp"
#include "expression.hpp"
#include "vector_grid_function.hpp"
#include "dim2_index.hpp"

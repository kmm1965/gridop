#pragma once

#include "../define_function.h"

#define _PARSEC_BEGIN _FUNCPROG_BEGIN namespace parsec {
#define _PARSEC_END } _FUNCPROG_END

#define _PARSEC _FUNCPROG::parsec

_PARSEC_BEGIN

using namespace _FUNCPROG;

_PARSEC_END
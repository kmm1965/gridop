#pragma once

_KIAM_MATH_BEGIN

template<class T, size_t N>
struct array_value
{
	typedef array_value type;
	typedef T data_type;
	typedef data_type *pointer;
	typedef const data_type *const_pointer;
	typedef data_type &reference;
	typedef const data_type &const_reference;
	static const size_t array_size = N;

	__DEVICE __HOST
	array_value(){
		fill_n(m_values, array_size, data_type());
	}

	__DEVICE __HOST
	array_value(const array_value &rhs){
		copy(rhs.m_values, rhs.m_values + array_size, m_values);
	}

	__DEVICE __HOST
	pointer values(){ return m_values; }

	__DEVICE __HOST
	const_pointer values() const { return m_values; }

	__DEVICE __HOST
	data_type operator[](size_t i) const { return m_values[i]; }

	__DEVICE __HOST
	reference operator[](size_t i){ return m_values[i]; }

	__DEVICE __HOST
	array_value& operator+=(const array_value &rhs)
	{
		transform_n(m_values, rhs.m_values, array_size, m_values, plus<data_type>());
		return *this;
	}

	__DEVICE __HOST
	array_value& operator-=(const array_value &rhs)
	{
		transform_n(m_values, rhs.m_values, array_size, m_values, minus<data_type>());
		return *this;
	}

	__DEVICE __HOST
	array_value& operator*=(data_type rhs)
	{
		transform_n(m_values, array_size, m_values, math_bind2nd(multiplies<data_type>(), rhs));
		return *this;
	}

	__DEVICE __HOST
	array_value& operator/=(data_type rhs)
	{
		transform_n(m_values, array_size, m_values, math_bind2nd(divides<data_type>(), rhs));
		return *this;
	}

	__DEVICE __HOST
	data_type length() const {
		return func::sqrt(math_inner_product(m_values, m_values + array_size, m_values));
	}

	__DEVICE __HOST
	array_value operator-() const
	{
		array_value result;
		transform_n(m_values, array_size, result.m_values, negate<data_type>());
		return result;
	}

	__DEVICE __HOST
	data_type sqr() const {
		return *this & *this;
	}

	__DEVICE __HOST
	data_type abs() const {
		return length();
	}

	__DEVICE __HOST
	bool operator==(const array_value &rhs) const {
		return math_inner_product(m_values, m_values + array_size, rhs.m_values, true, logical_and<bool>(), equal_to<data_type>());
	}

	__DEVICE __HOST
	bool operator!=(const array_value &rhs) const {
		return math_inner_product(m_values, m_values + array_size, rhs.m_values, false, logical_or<bool>(), not_equal_to<data_type>());
	}

private:
	data_type m_values[array_size];
};

template<class T, size_t N>
__DEVICE __HOST
array_value<T, N> operator+(const array_value<T, N> &x, const array_value<T, N> &y)
{
	array_value<T, N> result;
	transform_n(x.values(), y.values(), N, result.values(), plus<T>());
	return result;
}

template<class T, size_t N>
__DEVICE __HOST
array_value<T, N> operator-(const array_value<T, N> &x, const array_value<T, N> &y)
{
	array_value<T, N> result;
	transform_n(x.values(), y.values(), N, result.values(), minus<T>());
	return result;
}

template<class T, size_t N>
__DEVICE __HOST
array_value<T, N> operator*(const array_value<T, N> &x, T y)
{
	array_value<T, N> result;
	transform_n(x.values(), N, result.values(), math_bind2nd(multiplies<T>(), y));
	return result;
}

template<class T, size_t N>
__DEVICE __HOST
array_value<T, N> operator*(T x, const array_value<T, N> &y)
{
	array_value<T, N> result;
	transform_n(y.values(), N, result.values(), math_bind1st(multiplies<T>(), x));
	return result;
}

template<class T, size_t N>
__DEVICE __HOST
array_value<T, N> operator/(const array_value<T, N> &x, T y)
{
	array_value<T, N> result;
	transform_n(x.values(), N, result.values(), math_bind2nd(divides<T>(), y));
	return result;
}

// ��������� ������������
template<class T, size_t N>
__DEVICE __HOST
T operator&(const array_value<T, N> &x, const array_value<T, N> &y){
	return math_inner_product(x.values(), x.values() + N, y.values(), T());
}

// �������������� ������������
template<class T, size_t N>
__DEVICE __HOST
array_value<T, N> operator^(const array_value<T, N> &x, const array_value<T, N> &y)
{
	array_value<T, N> result;
	trs_convertible_from_testeransform_n(x.values(), y.values(), N, result.values(), multiplies<T>());
	return result;
}

template <class T> struct is_array_value : std::false_type {};
template <class T> struct is_array_value<const T> : is_array_value<T>{};
template <class T> struct is_array_value<volatile const T> : is_array_value<T>{};
template <class T> struct is_array_value<volatile T> : is_array_value<T>{};
template<class T, size_t N> struct is_array_value<array_value<T, N> > : std::true_type{};

template<typename T, size_t N>
struct supports_multiplies<array_value<T, N>, T> : std::true_type{};

template<typename T, size_t N>
struct multiplies_result_type<array_value<T, N>, T>
{
	typedef array_value<T, N> type;
};

template<typename T, size_t N>
struct supports_divides<array_value<T, N>, T> : std::true_type{};

template<typename T, size_t N>
struct divides_result_type<array_value<T, N>, T>
{
	typedef array_value<T, N> type;
};

template<typename T, size_t N>
struct supports_scalar_product<array_value<T, N>, array_value<T, N> > : std::true_type{};

template<typename T, size_t N>
struct scalar_product_result_type<array_value<T, N>, array_value<T, N> >
{
	typedef T type;
};

template<typename T, size_t N>
struct supports_component_product<array_value<T, N>, array_value<T, N> > : std::true_type{};

template<typename T, size_t N>
struct component_product_result_type<array_value<T, N>, array_value<T, N> >
{
	typedef array_value<T, N> type;
};

template<typename T, size_t N>
struct has_data_type<array_value<T, N> > : std::true_type{};

template<typename T, size_t N>
struct get_scalar_type<array_value<T, N> >
{
	typedef T type;
};

_KIAM_MATH_END

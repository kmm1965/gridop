#pragma once

#include "math_def.h"

_KIAM_MATH_BEGIN

template<class T>
struct vector2_value
{
	typedef vector2_value type;
	typedef T data_type;
	typedef data_type& reference;
	typedef const data_type &const_reference;

	__DEVICE __HOST
	vector2_value() : m_value_x(data_type()), m_value_y(data_type()){}

	__DEVICE __HOST
	vector2_value(data_type x, data_type y) : m_value_x(x), m_value_y(y){}

	__DEVICE __HOST
	vector2_value(const vector2_value& rhs) : m_value_x(rhs.value_x()), m_value_y(rhs.value_y()){}

	__DEVICE __HOST
	vector2_value& operator=(const vector2_value &rhs)
	{
		m_value_x = rhs.value_x();
		m_value_y = rhs.value_y();
		return *this;
	}

	__DEVICE __HOST
	void set(const data_type &x, const data_type &y)
	{
		m_value_x = x;
		m_value_y = y;
	}

	__DEVICE __HOST
	const_reference value_x() const { return m_value_x; }

	__DEVICE __HOST
	const_reference value_y() const { return m_value_y; }

	__DEVICE __HOST
	reference value_x(){ return m_value_x; }

	__DEVICE __HOST
	reference value_y(){ return m_value_y; }

	__DEVICE __HOST
	void value_x(const data_type& value){ m_value_x = value; }

	__DEVICE __HOST
	void value_y(const data_type& value){ m_value_y = value; }

	__DEVICE __HOST
	vector2_value& operator+=(const vector2_value& rhs)
	{
		m_value_x += rhs.value_x();
		m_value_y += rhs.value_y();
		return *this;
	}

	__DEVICE __HOST
	vector2_value& operator-=(const vector2_value& rhs)
	{
		m_value_x -= rhs.value_x();
		m_value_y -= rhs.value_y();
		return *this;
	}

	__DEVICE __HOST
	vector2_value& operator*=(data_type rhs)
	{
		m_value_x *= rhs;
		m_value_y *= rhs;
		return *this;
	}

	__DEVICE __HOST
	vector2_value& operator/=(data_type rhs)
	{
		m_value_x /= rhs;
		m_value_y /= rhs;
		return *this;
	}

	__DEVICE __HOST
	data_type length() const {
		return _KIAM_MATH::func::sqrt(m_value_x * m_value_x + m_value_y * m_value_y);
	}

	__DEVICE __HOST
	data_type sqr() const {
		return m_value_x * m_value_x + m_value_y * m_value_y;
	}

	__DEVICE __HOST
	vector2_value operator-() const {
		return vector2_value(-m_value_x, -m_value_y);
	}

	__DEVICE __HOST
	bool operator==(const vector2_value& rhs) const {
		return m_value_x == rhs.value_x() && m_value_y == rhs.value_y();
	}

	__DEVICE __HOST
	bool operator!=(const vector2_value& rhs) const {
		return m_value_x != rhs.value_x() || m_value_y != rhs.value_y();
	}

	__DEVICE __HOST
	vector2_value norm(){
		return *this *= 1 / length();
	}

private:
	data_type m_value_x, m_value_y;
};

template<class T>
__DEVICE __HOST
vector2_value<T> operator+(const vector2_value<T>& x, const vector2_value<T>& y){
	return vector2_value<T>(x.value_x() + y.value_x(), x.value_y() + y.value_y());
}

template<class T>
__DEVICE __HOST
vector2_value<T> operator-(const vector2_value<T>& x, const vector2_value<T>& y){
	return vector2_value<T>(x.value_x() - y.value_x(), x.value_y() - y.value_y());
}

template<class T>
__DEVICE __HOST
vector2_value<T> operator*(const vector2_value<T>& x, T y){
	return vector2_value<T>(x.value_x() * y, x.value_y() * y);
}

template<class T>
__DEVICE __HOST
vector2_value<T> operator*(T x, const vector2_value<T>& y){
	return vector2_value<T>(x * y.value_x(), x * y.value_y());
}

template<class T>
__DEVICE __HOST
vector2_value<T> operator/(const vector2_value<T>& x, T y){
	return vector2_value<T>(x.value_x() / y, x.value_y() / y);
}

// �������������� �������
template<class T>
__DEVICE __HOST
vector2_value<T> operator/(const vector2_value<T> &x, const vector2_value<T> &y){
	return vector2_value<T>(x.value_x() / y.value_x(), x.value_y() / y.value_y());
}

// ��������� ������������
template<class T>
__DEVICE __HOST
T operator&(const vector2_value<T>& x, const vector2_value<T>& y){
	return x.value_x() * y.value_x() + x.value_y() * y.value_y();
}

// �������������� ������������
template<class T>
__DEVICE __HOST
vector2_value<T> operator^(const vector2_value<T>& x, const vector2_value<T>& y){
	return vector2_value<T>(
		x.value_x() * y.value_x(),
		x.value_y() * y.value_y());
}

template<class T>
__DEVICE __HOST
T operator*(const vector2_value<T>& x, const vector2_value<T>& y){
	return x.value_x() * y.value_y() - x.value_y() * y.value_x();
}

// ������� ������������, ������������ �� �������� x � y
template<class T>
__DEVICE __HOST
T area_2D(const vector2_value<T>& x, const vector2_value<T>& y){
	return func::abs(x.value_x() * y.value_y() - x.value_y() * y.value_x()) / 2;
}

namespace func {

template<class T>
__DEVICE __HOST
T sqr(const vector2_value<T>& x){
	return x & x;
}

template<class T>
__DEVICE __HOST
T abs(const vector2_value<T>& x){
	return x.length();
}

template<class T>
__DEVICE __HOST
vector2_value<T> vabs(const vector2_value<T>& x){
	return vector2_value<T>(math_abs(x.value_x()), math_abs(x.value_y()));
}

template<class T>
__DEVICE __HOST
T sum_abs(const vector2_value<T>& x){
	return math_abs(x.value_x()) + math_abs(x.value_y());
}

}	// namespace func

template <class T> struct is_vector2_value : std::false_type {};
template <class T> struct is_vector2_value<const T> : is_vector2_value<T>{};
template <class T> struct is_vector2_value<volatile const T> : is_vector2_value<T>{};
template <class T> struct is_vector2_value<volatile T> : is_vector2_value<T>{};
template <class T> struct is_vector2_value<vector2_value<T> > : std::true_type{};

template<typename T>
struct supports_multiplies<vector2_value<T>, T> : std::true_type{};

template<typename T>
struct multiplies_result_type<vector2_value<T>, T>
{
	typedef vector2_value<T> type;
};

template<typename T>
struct supports_multiplies<T, vector2_value<T> > : std::true_type{};

template<typename T>
struct multiplies_result_type<T, vector2_value<T> >
{
	typedef vector2_value<T> type;
};

template<typename T>
struct supports_divides<vector2_value<T>, T> : std::true_type{};

template<typename T>
struct divides_result_type<vector2_value<T>, T>
{
	typedef vector2_value<T> type;
};

template<typename T>
struct supports_scalar_product<vector2_value<T>, vector2_value<T> > : std::true_type{};

template<typename T>
struct scalar_product_result_type<vector2_value<T>, vector2_value<T> >
{
	typedef T type;
};

template<typename T>
struct supports_component_product<vector2_value<T>, vector2_value<T> > : std::true_type{};

template<typename T>
struct component_product_result_type<vector2_value<T>, vector2_value<T> >
{
	typedef vector2_value<T> type;
};

template<typename T>
struct has_data_type<vector2_value<T> > : std::true_type{};

template<typename T>
struct get_scalar_type<vector2_value<T> >
{
	typedef T type;
};

_KIAM_MATH_END

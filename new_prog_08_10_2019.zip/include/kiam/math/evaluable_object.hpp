#pragma once

#include "math_object.hpp"
#include "type_traits.hpp"
#include "funcprog/Monad.hpp"

_KIAM_MATH_BEGIN

template<typename TAG>
struct _evaluable_object
{
    using tag_type = TAG;
    using base_class = _evaluable_object;
};

template<class TAG, class EO, class _Proxy = EO>
struct evaluable_object : math_object<EO, _Proxy>, _evaluable_object<TAG>
{
protected: // protect from direct construction
    evaluable_object() {}
};

// Functor
template<class EO, typename Ret, typename Arg, typename... Args>
struct fmap_evaluable_object : evaluable_object<typename EO::tag_type, fmap_evaluable_object<EO, Ret, Arg, Args...> >
{
    static_assert(funcprog::is_same_as<funcprog::value_type_t<EO>, Arg>::value, "Should be the same");

    using value_type = funcprog::remove_f0_t<funcprog::function_t<Ret(Args...)> >;
    using function_type = funcprog::function_t<Ret(Arg, Args...)>;
    using eobj_type = evaluable_object<typename EO::tag_type, EO, typename EO::proxy_type>;

    fmap_evaluable_object(function_type const& f, eobj_type const& eobj) : f(f), eobj_proxy(eobj.get_proxy()) {}

    value_type operator[](size_t i) const {
        return funcprog::invoke_f0(funcprog::operator<<(f, eobj_proxy[i]));
    }

private:
    const function_type f;
    const typename EO::proxy_type eobj_proxy;
};

template<class EO, typename Ret, typename Arg, typename... Args>
fmap_evaluable_object<EO, Ret, Arg, Args...>
operator/(funcprog::function_t<Ret(Arg, Args...)> const& f, evaluable_object<typename EO::tag_type, EO, typename EO::proxy_type> const& eobj) {
    return fmap_evaluable_object<EO, Ret, Arg, Args...>(f, eobj);
}

#define DECLARE_FUNC_EVAL_OBJ(name) \
	template<typename EO> \
	fmap_evaluable_object<EO, typename EO::value_type, typename EO::value_type> \
	name(evaluable_object<typename EO::tag_type, EO, typename EO::proxy_type> const& eobj){ \
		return funcprog::_((typename EO::value_type(*)(typename EO::value_type)) func::name) / eobj; \
	}

DECLARE_FUNC_EVAL_OBJ(sin)
DECLARE_FUNC_EVAL_OBJ(cos)
DECLARE_FUNC_EVAL_OBJ(tan)
DECLARE_FUNC_EVAL_OBJ(asin)
DECLARE_FUNC_EVAL_OBJ(acos)
DECLARE_FUNC_EVAL_OBJ(atan)
DECLARE_FUNC_EVAL_OBJ(sinh)
DECLARE_FUNC_EVAL_OBJ(cosh)
DECLARE_FUNC_EVAL_OBJ(tanh)
DECLARE_FUNC_EVAL_OBJ(ceil)
DECLARE_FUNC_EVAL_OBJ(floor)
DECLARE_FUNC_EVAL_OBJ(exp)
DECLARE_FUNC_EVAL_OBJ(log)
DECLARE_FUNC_EVAL_OBJ(log10)
DECLARE_FUNC_EVAL_OBJ(sqrt)

// Applicative
template<typename TAG, typename T>
struct pure_evaluable_object : evaluable_object<TAG, pure_evaluable_object<TAG, T> >
{
    using value_type = T;

    pure_evaluable_object(value_type const& value) : value(value) {}

    __DEVICE
    value_type operator[](size_t) const {
        return value;
    }

private:
    const value_type value;
};

template<class EO_F, class EO>
struct apply_evaluable_object : evaluable_object<typename EO::tag_type, apply_evaluable_object<EO_F, EO> >
{
    static_assert(std::is_same<typename EO::tag_type, typename EO_F::tag_type>::value, "The tag should be the same");
    static_assert(funcprog::is_function<typename EO_F::value_type>::value, "Should be a function");
    static_assert(funcprog::is_same_as<typename EO::value_type, funcprog::first_argument_type_t<typename EO_F::value_type> >::value, "Should be the same");

    using value_type = funcprog::remove_f0_t<funcprog::remove_first_arg_t<typename EO_F::value_type> >;
#ifdef __CUDACC__
    static_assert(!funcprog::is_function<value_type>::value, "Should not be a function");
#endif
    using eobj_f_type = evaluable_object<typename EO_F::tag_type, EO_F, typename EO_F::proxy_type>;
    using eobj_type = evaluable_object<typename EO::tag_type, EO, typename EO::proxy_type>;

    apply_evaluable_object(eobj_f_type const& eobj_f, eobj_type const& eobj) : eobj_f_proxy(eobj_f.get_proxy()), eobj_proxy(eobj.get_proxy()) {}

    __DEVICE
    value_type operator[](size_t i) const
    {
#ifdef __CUDACC__
        return eobj_f_proxy[i](eobj_proxy[i]);
#else
        using funcprog::operator<<;
        return funcprog::invoke_f0(eobj_f_proxy[i] << eobj_proxy[i]);
#endif
    }

private:
    const typename EO_F::proxy_type eobj_f_proxy;
    const typename EO::proxy_type eobj_proxy;
};

template<class EO_F, class EO>
std::enable_if_t<
	funcprog::is_function<typename EO_F::value_type>::value,
	apply_evaluable_object<EO_F, EO>
> operator*(evaluable_object<typename EO_F::tag_type, EO_F, typename EO_F::proxy_type> const& eobj_f,
    evaluable_object<typename EO::tag_type, EO, typename EO::proxy_type> const& eobj)
{
    return apply_evaluable_object<EO_F, EO>(eobj_f, eobj);
}

// Monad
template<class EO, class EORet, typename Arg>
struct mbind_evaluable_object : evaluable_object<typename EO::tag_type, mbind_evaluable_object<EO, EORet, Arg> >
{
    static_assert(std::is_same<typename EO::tag_type, typename EORet::tag_type>::value, "Tags should be the same");
    static_assert(funcprog::is_same_as<typename EO::value_type, Arg>::value, "Should be the same");

    using value_type = funcprog::value_type_t<EORet>;
    using function_type = funcprog::function_t<EORet(Arg)>;

    mbind_evaluable_object(evaluable_object<typename EO::tag_type, EO, typename EO::proxy_type> const& eobj,
        function_type const& f) : eobj_proxy(eobj.get_proxy()), f(f) {}

    __DEVICE
    value_type operator[](size_t i) const {
        return f(eobj_proxy[i])[i];
    }

private:
    const typename EO::proxy_type eobj_proxy;
    const function_type f;
};

template<class EO, class EORet, typename Arg>
static std::enable_if_t<
    std::is_same<typename EO::tag_type, typename EORet::tag_type>::value && funcprog::is_same_as<funcprog::value_type_t<EO>, Arg>::value,
    mbind_evaluable_object<EO, EORet, Arg>
> operator>>=(evaluable_object<typename EO::tag_type, EO, typename EO::proxy_type> const& eobj, funcprog::function_t<EORet(Arg)> const& f) {
    return mbind_evaluable_object<EO, EORet, Arg>(eobj, f);
}

template<class EO, class EORet, typename Arg>
static std::enable_if_t<
    std::is_same<typename EO::tag_type, typename EORet::tag_type>::value&& funcprog::is_same_as<funcprog::value_type_t<EO>, Arg>::value,
    mbind_evaluable_object<EO, EORet, Arg>
> operator<<=(funcprog::function_t<EORet(Arg)> const& f, evaluable_object<typename EO::tag_type, EO, typename EO::proxy_type> const& eobj) {
    return eobj >>= f;
}

namespace funcprog {

    // Functor
    template<typename TAG>
    struct is_functor<_KIAM_MATH::_evaluable_object<TAG> > : std::true_type {};

    template<typename TAG>
    struct is_same_functor<_KIAM_MATH::_evaluable_object<TAG>, _KIAM_MATH::_evaluable_object<TAG> > : std::true_type {};

    template<typename TAG>
    struct Functor<_KIAM_MATH::_evaluable_object<TAG> >
    {
        // <$> fmap :: Functor f => (a -> b) -> f a -> f b
        template<class EO, typename Ret, typename Arg, typename... Args>
        static _KIAM_MATH::fmap_evaluable_object<EO, Ret, Arg, Args...>
            fmap(function_t<Ret(Arg, Args...)> const& f, _KIAM_MATH::evaluable_object<typename EO::tag_type, EO, typename EO::proxy_type> const& eobj)
        {
            static_assert(std::is_same<TAG, typename EO::tag_type>::value, "Tags should be the same");
            return _KIAM_MATH::fmap_evaluable_object<EO, Ret, Arg, Args...>(f, eobj);
        }
    };

    // Applicative
    template<typename TAG>
    struct is_applicative<_KIAM_MATH::_evaluable_object<TAG> > : std::true_type {};

    template<typename TAG>
    struct is_same_applicative<_KIAM_MATH::_evaluable_object<TAG>, _KIAM_MATH::_evaluable_object<TAG> > : std::true_type {};

    template<typename TAG>
    struct Applicative<_KIAM_MATH::_evaluable_object<TAG> > : Functor<_KIAM_MATH::_evaluable_object<TAG> >
    {
        using super = Functor<_KIAM_MATH::_evaluable_object<TAG> >;

        template<typename T>
        static _KIAM_MATH::pure_evaluable_object<TAG, T> pure(T const& value) {
            return _KIAM_MATH::pure_evaluable_object<TAG, T>(value);
        }

        // <*> :: Applicative f => f (a -> b) -> f a -> f b
        template<class EO, class EO_F>
        static _KIAM_MATH::apply_evaluable_object<EO_F, EO>
            apply(_KIAM_MATH::evaluable_object<typename EO_F::tag_type, EO_F, typename EO_F::proxy_type> const& eobj_f,
                _KIAM_MATH::evaluable_object<typename EO::tag_type, EO, typename EO::proxy_type> const& eobj)
        {
            static_assert(std::is_same<TAG, typename EO::tag_type>::value, "Tags should be the same");
            return _KIAM_MATH::apply_evaluable_object<EO_F, EO>(eobj_f, eobj);
        }
    };

    // Monad
    template<typename TAG>
    struct is_monad<_KIAM_MATH::_evaluable_object<TAG> > : std::true_type {};

    template<typename TAG>
    struct is_same_monad<_KIAM_MATH::_evaluable_object<TAG>, _KIAM_MATH::_evaluable_object<TAG> > : std::true_type {};

    template<typename TAG>
    struct Monad<_KIAM_MATH::_evaluable_object<TAG> > : Applicative<_KIAM_MATH::_evaluable_object<TAG> >
    {
        using super = Applicative<_KIAM_MATH::_evaluable_object<TAG> >;

        //template<typename T>
        //using liftM_type = _KIAM_MATH::mbind_evaluable_object<EO, _KIAM_MATH::pure_evaluable_object<TAG, T>, T>

        template<typename T>
        static _KIAM_MATH::pure_evaluable_object<TAG, T> mreturn(T const& value) {
            return super::pure(value);
        }

        template<class EO, class EORet, typename Arg>
        static std::enable_if_t<
            std::is_same<TAG, typename EO::tag_type>::value&&
            std::is_same<TAG, typename EORet::tag_type>::value&&
            is_same_as<value_type_t<EO>, Arg>::value,
            _KIAM_MATH::mbind_evaluable_object<EO, EORet, Arg>
        > mbind(
            _KIAM_MATH::evaluable_object<typename EO::tag_type, EO, typename EO::proxy_type> const& eobj,
            function_t<EORet(Arg)> const& f)
        {
            return _KIAM_MATH::mbind_evaluable_object<EO, EORet, Arg>(eobj, f);
        }

        template<typename Ret, typename Arg, typename... Args>
        using lift_type = function_t<_KIAM_MATH::pure_evaluable_object<TAG, remove_f0_t<function_t<Ret(Args...)> > >(Arg)>;

        template<typename Ret, typename Arg, typename... Args>
        static lift_type<Ret, Arg, Args...> lift(function_t<Ret(Arg, Args...)> const& f) {
            return [f](Arg arg) {
                return _KIAM_MATH::pure_evaluable_object<TAG, remove_f0_t<function_t<Ret(Args...)> > >(invoke_f0(f << arg));
            };
        }
    };

    template<typename EO, typename Ret, typename Arg>
    _KIAM_MATH::mbind_evaluable_object<EO, _KIAM_MATH::pure_evaluable_object<typename EO::tag_type, Ret>, fdecay<Arg> const&>
        liftM(function_t<Ret(Arg)> const& f,
            _KIAM_MATH::evaluable_object<typename EO::tag_type, EO, typename EO::proxy_type> const& eobj)
    {
        return eobj >>= _([f](value_type_t<EO> const& x) {
            return Monad<_KIAM_MATH::_evaluable_object<typename EO::tag_type> >::mreturn(f(x));
        });
    }

} // namespace funcprog

#define BINARY_EO_OPERATOR(op, oper) \
    template<typename EO1, typename EO2> \
    std::enable_if_t< \
        std::is_same<typename EO1::tag_type, typename EO2::tag_type>::value && \
        std::is_same<typename EO1::value_type, typename EO2::value_type>::value, \
        apply_evaluable_object< \
            fmap_evaluable_object<EO1, typename EO1::value_type, \
                typename EO1::value_type const&, typename EO1::value_type const& \
            >, EO2 \
        > \
    > operator op( \
        evaluable_object<typename EO1::tag_type, EO1, typename EO1::proxy_type> const& eobj1, \
        evaluable_object<typename EO2::tag_type, EO2, typename EO2::proxy_type> const& eobj2 \
    ){ return funcprog::_(std::oper<typename EO1::value_type>()) / eobj1 * eobj2; }

BINARY_EO_OPERATOR(+, plus)
BINARY_EO_OPERATOR(-, minus)

template<typename EO1, typename EO2>
std::enable_if_t<
	std::is_same<typename EO1::tag_type, typename EO2::tag_type>::value &&
	supports_multiplies<typename EO1::value_type, typename EO2::value_type>::value,
	apply_evaluable_object<
		fmap_evaluable_object<EO1,
			multiplies_result_type_t<typename EO1::value_type, typename EO2::value_type>,
			typename EO1::value_type const&, typename EO2::value_type const&
		>, EO2
	>
> operator*(
	evaluable_object<typename EO1::tag_type, EO1, typename EO1::proxy_type> const& eobj1,
	evaluable_object<typename EO2::tag_type, EO2, typename EO2::proxy_type> const& eobj2
){
	return funcprog::_(get_generic_multiplies_t<typename EO1::value_type, typename EO2::value_type>()) / eobj1 * eobj2;
}

template<typename EO1, typename EO2>
std::enable_if_t<
	std::is_same<typename EO1::tag_type, typename EO2::tag_type>::value &&
	supports_divides<typename EO1::value_type, typename EO2::value_type>::value,
	apply_evaluable_object<
		fmap_evaluable_object<EO1,
			divides_result_type_t<typename EO1::value_type, typename EO2::value_type>,
			typename EO1::value_type const&, typename EO2::value_type const&
		>, EO2
	>
> operator/(
	evaluable_object<typename EO1::tag_type, EO1, typename EO1::proxy_type> const& eobj1,
	evaluable_object<typename EO2::tag_type, EO2, typename EO2::proxy_type> const& eobj2
){
	return funcprog::_(get_generic_divides_t<typename EO1::value_type, typename EO2::value_type>()) / eobj1 * eobj2;
}

#define BINARY_VAL_EO_OPERATOR(op) \
    template<typename EO> \
    apply_evaluable_object< \
        fmap_evaluable_object< \
            pure_evaluable_object<typename EO::tag_type, typename EO::value_type>, \
            typename EO::value_type, typename EO::value_type const&, typename EO::value_type const& \
        >, EO \
    > operator op( \
        typename EO::value_type const& value, \
        evaluable_object<typename EO::tag_type, EO, typename EO::proxy_type> const& eobj \
    ){ return funcprog::Applicative<_evaluable_object<typename EO::tag_type> >::pure(value) op eobj; }

BINARY_VAL_EO_OPERATOR(+)
BINARY_VAL_EO_OPERATOR(-)

template<typename EO>
apply_evaluable_object<
    fmap_evaluable_object<
        pure_evaluable_object<typename EO::tag_type, get_scalar_type_t<typename EO::value_type> >,
        typename EO::value_type, get_scalar_type_t<typename EO::value_type> const&, typename EO::value_type const&
    >, EO
> operator*(
    get_scalar_type_t<typename EO::value_type> const& value,
    evaluable_object<typename EO::tag_type, EO, typename EO::proxy_type> const& eobj
){
	return funcprog::_(generic_multiplies<get_scalar_type_t<typename EO::value_type>, typename EO::value_type, typename EO::value_type>()) /
		funcprog::Applicative<_evaluable_object<typename EO::tag_type> >::pure(value) * eobj;
}

template<typename EO>
std::enable_if_t<
	supports_divides<
		typename get_scalar_type<typename EO::value_type>::type,
		typename EO::value_type
	>::value,
	apply_evaluable_object<
		fmap_evaluable_object<
			pure_evaluable_object<typename EO::tag_type, get_scalar_type_t<typename EO::value_type> >,
			typename EO::value_type, get_scalar_type_t<typename EO::value_type> const&, typename EO::value_type const&
		>, EO
	>
> operator/(
    get_scalar_type_t<typename EO::value_type> const& value,
    evaluable_object<typename EO::tag_type, EO, typename EO::proxy_type> const& eobj
){
	return funcprog::_(get_generic_divides_t<get_scalar_type_t<typename EO::value_type>, typename EO::value_type>()) /
		funcprog::Applicative<_evaluable_object<typename EO::tag_type> >::pure(value) * eobj;
}

#define BINARY_EO_VAL_OPERATOR(op) \
    template<typename EO> \
    apply_evaluable_object< \
        fmap_evaluable_object<EO, \
            typename EO::value_type, typename EO::value_type const&, typename EO::value_type const& \
        >, pure_evaluable_object<typename EO::tag_type, typename EO::value_type> \
    > operator op( \
        evaluable_object<typename EO::tag_type, EO, typename EO::proxy_type> const& eobj, \
        typename EO::value_type const& value \
    ){ return eobj op funcprog::Applicative<_evaluable_object<typename EO::tag_type> >::pure(value); }

BINARY_EO_VAL_OPERATOR(+)
BINARY_EO_VAL_OPERATOR(-)

template<typename EO>
apply_evaluable_object<
    fmap_evaluable_object<EO,
        typename EO::value_type, typename EO::value_type const&, get_scalar_type_t<typename EO::value_type> const&
    >, pure_evaluable_object<typename EO::tag_type, get_scalar_type_t<typename EO::value_type> >
> operator*(
    evaluable_object<typename EO::tag_type, EO, typename EO::proxy_type> const& eobj,
    get_scalar_type_t<typename EO::value_type> const& value
){
	return funcprog::_(generic_multiplies<typename EO::value_type, get_scalar_type_t<typename EO::value_type>, typename EO::value_type>()) /
		eobj * funcprog::Applicative<_evaluable_object<typename EO::tag_type> >::pure(value);
}

template<typename EO>
apply_evaluable_object<
	fmap_evaluable_object<EO,
		typename EO::value_type, typename EO::value_type const&, get_scalar_type_t<typename EO::value_type> const&
	>, pure_evaluable_object<typename EO::tag_type, get_scalar_type_t<typename EO::value_type> >
> operator/(
	evaluable_object<typename EO::tag_type, EO, typename EO::proxy_type> const& eobj,
	get_scalar_type_t<typename EO::value_type> const& value
){
	return funcprog::_(generic_divides<typename EO::value_type, get_scalar_type_t<typename EO::value_type>, typename EO::value_type>()) /
		eobj * funcprog::Applicative<_evaluable_object<typename EO::tag_type> >::pure(value);
}

template<typename EO>
fmap_evaluable_object<EO, typename EO::value_type, typename EO::value_type const&>
operator-(evaluable_object<typename EO::tag_type, EO, typename EO::proxy_type> const& eobj) {
    return funcprog::_(std::negate<typename EO::value_type>()) / eobj;
}

#ifdef __CUDACC__
DECLARE_FUNC_EVAL_OBJ(sinpi)
DECLARE_FUNC_EVAL_OBJ(cospi)
DECLARE_FUNC_EVAL_OBJ(exp2)
DECLARE_FUNC_EVAL_OBJ(log1p)
DECLARE_FUNC_EVAL_OBJ(log2)
#endif	// __CUDACC__

_KIAM_MATH_END

#ifdef DONT_USE_CXX_11
#define DECLARE_MATH_EVALUABLE_OBJECT(name) \
	template<class EO, class _Proxy = EO> \
	struct name##_evaluable_object : _KIAM_MATH::evaluable_object<name##_tag, EO, _Proxy>{}
#else
#define DECLARE_MATH_EVALUABLE_OBJECT(name) \
	template<class EO, class _Proxy = EO> \
	using name##_evaluable_object = _KIAM_MATH::evaluable_object<name##_tag, EO, _Proxy>
#endif

#include "funcprog/detail/func_impl.hpp"

#pragma once

#include "kiam_math.h"

_KIAM_MATH_BEGIN

#if defined(__CUDACC__)

template<typename _Arg, typename _Result>
struct math_unary_function : thrust::unary_function<_Arg, _Result> {};

template<typename _Arg1, typename _Arg2, typename _Result>
struct math_binary_function : thrust::binary_function<_Arg1, _Arg2, _Result> {};

#elif defined(__OPENCL__)

template<typename _Arg, typename _Result>
struct math_unary_function : ::boost::compute::unary_function<_Arg, _Result> {};

template<typename _Arg1, typename _Arg2, typename _Result>
struct math_binary_function : ::boost::compute::binary_function<_Arg1, _Arg2, _Result> {};

#else

template<typename _Arg, typename _Result>
struct math_unary_function : std::unary_function<_Arg, _Result> {};

template<typename _Arg1, typename _Arg2, typename _Result>
struct math_binary_function : std::binary_function<_Arg1, _Arg2, _Result> {};

#endif

_KIAM_MATH_END
